// Campaigns.jsx — Broadcast campaigns list + builder

function Campaigns() {
  const T = ClinicalTokens;

  const campaigns = [
    { name: 'Annual physical reminder', status: 'Running', sent: 142, replied: 89, booked: 47, ch: 'sms', perf: 33, color: T.accent },
    { name: 'Flu shot — Saturday clinic', status: 'Running', sent: 386, replied: 124, booked: 78, ch: 'whatsapp', perf: 20, color: T.success },
    { name: 'Dormant patient re-engagement', status: 'Draft', sent: 0, replied: 0, booked: 0, ch: 'email', perf: 0, color: T.textFaint },
    { name: 'New patient welcome (3-touch)', status: 'Running', sent: 47, replied: 41, booked: 12, ch: 'sms', perf: 26, color: T.accent },
    { name: 'Birthday greetings 2026', status: 'Scheduled', sent: 0, replied: 0, booked: 0, ch: 'sms', perf: 0, color: T.warn },
    { name: 'Lab follow-up auto', status: 'Running', sent: 218, replied: 84, booked: 22, ch: 'sms', perf: 10, color: T.accent },
    { name: 'Q1 NPS survey', status: 'Complete', sent: 1840, replied: 612, booked: 0, ch: 'email', perf: 0, color: '#7A5C9A' },
  ];

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex',
      background: T.bg, fontFamily: T.font, color: T.text, fontSize: 13,
    }}>
      <ClinicalSidebar2 active="Campaigns"/>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {/* header */}
        <div style={{ padding: '20px 32px 16px', background: T.surface, borderBottom: `1px solid ${T.border}`, display: 'flex', alignItems: 'flex-end', gap: 14 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11.5, color: T.textDim, fontFamily: T.mono, marginBottom: 4 }}>CAMPAIGNS</div>
            <h1 style={{ margin: 0, fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em' }}>Outreach</h1>
            <div style={{ fontSize: 12, color: T.textDim, marginTop: 4 }}>4 running · 1 scheduled · 1 draft</div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={{
              padding: '8px 14px', borderRadius: 7, background: T.surface, color: T.text,
              border: `1px solid ${T.border}`, fontFamily: 'inherit', fontSize: 12.5, cursor: 'pointer',
              display: 'inline-flex', alignItems: 'center', gap: 6, fontWeight: 500,
            }}>
              <Icons.sparkles size={13} stroke={T.accent}/> Suggest from inbox
            </button>
            <button style={{
              padding: '8px 14px', borderRadius: 7, background: T.accent, color: '#fff',
              border: 'none', fontFamily: 'inherit', fontSize: 12.5, cursor: 'pointer',
              display: 'inline-flex', alignItems: 'center', gap: 6, fontWeight: 600,
            }}>
              <Icons.plus size={13} strokeWidth={2}/> New campaign
            </button>
          </div>
        </div>

        {/* content split */}
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          {/* list */}
          <div style={{ width: 380, borderRight: `1px solid ${T.border}`, background: T.surface, overflow: 'auto' }}>
            <div style={{ padding: '10px 14px', display: 'flex', gap: 5, borderBottom: `1px solid ${T.border}` }}>
              {['All', 'Running', 'Scheduled', 'Drafts', 'Complete'].map((t, i) => (
                <span key={i} style={{
                  fontSize: 11.5, padding: '4px 10px', borderRadius: 5,
                  background: i === 0 ? T.accentSoft : 'transparent',
                  color: i === 0 ? T.accent : T.textDim,
                  border: `1px solid ${i === 0 ? T.accentSoft : T.border}`,
                  cursor: 'pointer', fontWeight: i === 0 ? 600 : 500,
                }}>{t}</span>
              ))}
            </div>
            {campaigns.map((c, i) => (
              <div key={i} style={{
                padding: '14px 16px', borderBottom: `1px solid ${T.border}`,
                cursor: 'pointer', background: i === 0 ? T.surfaceAlt : 'transparent',
                borderLeft: i === 0 ? `2px solid ${T.accent}` : '2px solid transparent',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                  <ChannelDot channel={c.ch} size={11}/>
                  <div style={{ flex: 1, fontSize: 13, fontWeight: i === 0 ? 600 : 500, color: T.text }}>{c.name}</div>
                  <span style={{
                    fontSize: 10, padding: '1px 7px', borderRadius: 3, fontWeight: 600,
                    background: c.status === 'Running' ? T.accentSoft : c.status === 'Draft' ? '#F0EEE7' : c.status === 'Scheduled' ? '#FBF6EC' : '#EDE9F2',
                    color: c.status === 'Running' ? T.accent : c.status === 'Draft' ? T.textDim : c.status === 'Scheduled' ? T.warn : '#7A5C9A',
                  }}>{c.status}</span>
                </div>
                <div style={{ display: 'flex', gap: 14, fontSize: 11, color: T.textDim, fontFamily: T.mono }}>
                  <span>{c.sent.toLocaleString()} sent</span>
                  {c.replied ? <span>{c.replied} replied</span> : null}
                  {c.booked ? <span style={{ color: T.success }}>{c.booked} booked</span> : null}
                </div>
                {c.perf > 0 ? (
                  <div style={{ marginTop: 8, height: 4, background: T.surfaceAlt, borderRadius: 2, overflow: 'hidden' }}>
                    <div style={{ width: `${c.perf}%`, height: '100%', background: c.color, borderRadius: 2 }}/>
                  </div>
                ) : null}
              </div>
            ))}
          </div>

          {/* builder */}
          <div style={{ flex: 1, overflow: 'auto', background: T.surfaceAlt, padding: '24px 32px' }}>
            <CampaignBuilder T={T}/>
          </div>
        </div>
      </div>
    </div>
  );
}

function CampaignBuilder({ T }) {
  return (
    <div style={{ maxWidth: 760, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* live results */}
      <div style={{
        background: T.surface, border: `1px solid ${T.border}`, borderRadius: 12, padding: 18,
      }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 14 }}>
          <h2 style={{ margin: 0, fontSize: 17, fontWeight: 600, letterSpacing: '-0.01em' }}>Annual physical reminder</h2>
          <span style={{ fontSize: 10.5, padding: '2px 8px', borderRadius: 4, background: T.accentSoft, color: T.accent, fontWeight: 600 }}>● Running</span>
          <span style={{ marginLeft: 'auto', fontSize: 11.5, color: T.textDim }}>Started May 14 · 8 days running</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
          {[
            { l: 'Sent', v: '142', sub: 'of 218 in segment' },
            { l: 'Replied', v: '89', sub: '63% reply rate', good: true },
            { l: 'Booked appts', v: '47', sub: '$2,068 projected', good: true },
            { l: 'Opted out', v: '3', sub: '2.1%', dim: true },
          ].map((k, i) => (
            <div key={i} style={{ padding: 12, background: T.surfaceAlt, borderRadius: 8 }}>
              <div style={{ fontSize: 10, color: T.textDim, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>{k.l}</div>
              <div style={{ fontSize: 22, fontWeight: 600, color: k.good ? T.success : k.dim ? T.textDim : T.text, fontFamily: T.mono, letterSpacing: '-0.02em' }}>{k.v}</div>
              <div style={{ fontSize: 11, color: T.textFaint, marginTop: 2 }}>{k.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* audience */}
      <BuilderBlock T={T} step="1" title="Audience" desc="218 patients due for annual physical (last visit > 11mo)">
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {[
            'Last visit > 11 months',
            'Active patient',
            'Not in another running campaign',
            'SMS opt-in',
            'Age 25+',
          ].map((f, i) => (
            <span key={i} style={{
              fontSize: 11.5, padding: '4px 10px', borderRadius: 5,
              background: T.accentSoft, color: T.accent, border: `1px solid ${T.accentSoft}`, fontWeight: 500,
            }}>{f}</span>
          ))}
          <button style={{
            fontSize: 11.5, padding: '4px 10px', borderRadius: 5,
            background: 'transparent', color: T.textDim, border: `1px dashed ${T.border}`,
            cursor: 'pointer', fontFamily: 'inherit',
          }}>+ Add</button>
        </div>
      </BuilderBlock>

      {/* sequence */}
      <BuilderBlock T={T} step="2" title="Sequence" desc="3 touches over 10 days · SMS-first, escalate to email if no reply">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[
            { d: 'Day 0', ch: 'sms', t: 'Initial — friendly SMS', body: 'Hi {{first}}, it\'s been a while! Looks like you\'re due for your annual physical. Want me to send open times this week?', sent: 142, opened: 138, replied: 89 },
            { d: 'Day 3', ch: 'sms', t: 'Reminder if no reply', body: 'Just a quick nudge — Dr. Lin has openings Thu/Fri. Reply YES and I\'ll book the first one that works.', sent: 53, opened: 51, replied: 18 },
            { d: 'Day 10', ch: 'email', t: 'Final · escalate to email', body: 'Subject: Time for your yearly checkup — pick a slot in 30 seconds. ↓ Includes self-book link.', sent: 35, opened: 22, replied: 0 },
          ].map((s, i) => (
            <div key={i} style={{ display: 'flex', gap: 12 }}>
              <div style={{
                width: 70, flexShrink: 0, fontSize: 11, color: T.textDim, fontFamily: T.mono, paddingTop: 6,
              }}>{s.d}</div>
              <div style={{
                flex: 1, padding: 12, background: T.surfaceAlt, border: `1px solid ${T.border}`, borderRadius: 8,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 6 }}>
                  <ChannelDot channel={s.ch} size={11}/>
                  <span style={{ fontSize: 12, fontWeight: 600 }}>{s.t}</span>
                  <span style={{ marginLeft: 'auto', fontSize: 11, color: T.textDim, fontFamily: T.mono }}>
                    {s.sent} sent · {s.replied} replied
                  </span>
                </div>
                <div style={{ fontSize: 12, color: T.textDim, lineHeight: 1.55, fontFamily: T.mono, padding: 8, background: T.surface, borderRadius: 5 }}>
                  {s.body}
                </div>
              </div>
            </div>
          ))}
          <button style={{
            alignSelf: 'flex-start', marginLeft: 82, fontSize: 11.5, padding: '6px 12px', borderRadius: 5,
            background: T.surface, color: T.textDim, border: `1px dashed ${T.borderStrong}`,
            cursor: 'pointer', fontFamily: 'inherit', display: 'inline-flex', alignItems: 'center', gap: 5,
          }}>
            <Icons.plus size={12}/> Add touchpoint
          </button>
        </div>
      </BuilderBlock>

      <BuilderBlock T={T} step="3" title="Goal & guardrails" desc="Track replies → bookings · respect quiet hours">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {[
            ['Primary goal', 'Booked appointment'],
            ['Attribution window', '14 days after first send'],
            ['Quiet hours', '9 PM – 8 AM local'],
            ['Frequency cap', '1 campaign per patient / 7d'],
            ['Opt-out keyword', 'STOP, UNSUBSCRIBE'],
            ['Auto-pause if reply rate', '< 8% after 200 sends'],
          ].map(([k, v], i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: i < 4 ? `1px solid ${T.border}` : 'none' }}>
              <span style={{ fontSize: 12, color: T.textDim }}>{k}</span>
              <span style={{ fontSize: 12, color: T.text, fontWeight: 500 }}>{v}</span>
            </div>
          ))}
        </div>
      </BuilderBlock>
    </div>
  );
}

function BuilderBlock({ T, step, title, desc, children }) {
  return (
    <div style={{ background: T.surface, border: `1px solid ${T.border}`, borderRadius: 12, padding: 18 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
        <span style={{
          width: 22, height: 22, borderRadius: 6, background: T.accentSoft, color: T.accent,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: T.mono, fontSize: 11, fontWeight: 700,
        }}>{step}</span>
        <h3 style={{ margin: 0, fontSize: 14, fontWeight: 600 }}>{title}</h3>
        <span style={{ fontSize: 11.5, color: T.textDim }}>{desc}</span>
        <button style={{
          marginLeft: 'auto', fontSize: 11, padding: '3px 9px', borderRadius: 4,
          background: 'transparent', color: T.textDim, border: `1px solid ${T.border}`,
          cursor: 'pointer', fontFamily: 'inherit',
        }}>Edit</button>
      </div>
      {children}
    </div>
  );
}

window.Campaigns = Campaigns;
