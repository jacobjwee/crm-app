// InboxWarm.jsx — Direction B: Warm Practice
// Soft cream surfaces, taupe sidebar, sage/clay accents. More human.
// Font: DM Sans (body) + Newsreader (display accents).

const WarmTokens = {
  font: "'DM Sans', system-ui, sans-serif",
  display: "'Newsreader', Georgia, serif",
  mono: "'Geist Mono', ui-monospace, monospace",
  bg: '#F4F0E8',        // warm cream
  surface: '#FBF7EE',
  surfaceAlt: '#EFEADD',
  border: '#E0D8C5',
  borderStrong: '#CDC2A8',
  text: '#241D14',
  textDim: '#6B5F4D',
  textFaint: '#9A8E78',
  sidebar: '#2A2218',   // deep warm brown
  sidebarText: 'rgba(244,240,232,0.75)',
  sidebarTextActive: '#FBF7EE',
  sidebarActive: 'rgba(154,178,142,0.18)',
  accent: '#5C7A4F',    // sage
  accentSoft: '#E6EDDC',
  clay: '#B85C3C',
  claySoft: '#F2DDCF',
  success: '#5C7A4F',
  warn: '#A8782B',
  danger: '#B85C3C',
};

const WarmThreads = [
  { id: 'w1', name: 'Maya Okafor', preview: 'Hi, can I move my Thursday 3pm? Something came up at work…', time: '2m', unread: 2, channel: 'sms', tag: 'Reschedule', active: true, ai: true },
  { id: 'w2', name: 'Daniel Reyes', preview: 'Just confirming I should fast 12hrs before the blood draw?', time: '9m', unread: 1, channel: 'whatsapp', tag: 'Pre-visit' },
  { id: 'w3', name: 'Aisha Patel', preview: 'Insurance card uploaded. Let me know if you need a different angle.', time: '14m', unread: 0, channel: 'sms', tag: 'Intake', attachment: true },
  { id: 'w4', name: 'Sofia Bianchi', preview: 'Felt much better after the new prescription. Quick question…', time: '38m', unread: 0, channel: 'sms', tag: 'Follow-up' },
  { id: 'w5', name: 'Marcus Lin', preview: 'No-show flag — appt was today 10am. Draft response ready.', time: '1h', unread: 1, channel: 'sms', tag: 'No-show', ai: true, flagged: true },
  { id: 'w6', name: 'Priya Ramaswamy', preview: 'Voice · 0:43 — "Hi, I was hoping to schedule…"', time: '2h', unread: 0, channel: 'voice', tag: 'New' },
  { id: 'w7', name: 'Owen Carter', preview: 'Confirmed for Monday at 2:15pm. See you then 👋', time: '3h', unread: 0, channel: 'sms', tag: '' },
  { id: 'w8', name: 'Rebecca Wu', preview: 'Form completed: New Patient Intake (4 pages).', time: '4h', unread: 0, channel: 'email', tag: 'Forms' },
];

function InboxWarm() {
  const T = WarmTokens;
  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex',
      background: T.bg, fontFamily: T.font, color: T.text,
      fontSize: 13,
    }}>
      {/* Sidebar — warm brown */}
      <aside style={{
        width: 224, background: T.sidebar, color: T.sidebarText,
        display: 'flex', flexDirection: 'column', flexShrink: 0, padding: '4px 0',
      }}>
        <div style={{ padding: '18px 20px 8px', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 28, height: 28, borderRadius: '50%',
            background: T.accent, color: T.sidebar,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: T.display, fontStyle: 'italic', fontWeight: 500, fontSize: 17,
          }}>L</div>
          <div>
            <div style={{ color: '#fff', fontFamily: T.display, fontSize: 19, fontWeight: 500, letterSpacing: '-0.01em', lineHeight: 1 }}>Lumen</div>
            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 10, marginTop: 2, letterSpacing: '0.1em', textTransform: 'uppercase' }}>Maple Family Clinic</div>
          </div>
        </div>

        <div style={{ padding: '12px 14px' }}>
          <button style={{
            width: '100%', padding: '9px 12px', borderRadius: 999,
            background: T.accent, color: '#fff', border: 'none',
            fontFamily: 'inherit', fontSize: 12.5, fontWeight: 500, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}>
            <Icons.edit size={13}/> New conversation
          </button>
        </div>

        <nav style={{ padding: '6px 10px', flex: 1, display: 'flex', flexDirection: 'column', gap: 1 }}>
          {[
            { icon: Icons.inbox, label: 'Inbox', badge: 12, active: true },
            { icon: Icons.dashboard, label: 'Today' },
            { icon: Icons.calendar, label: 'Schedule' },
            { icon: Icons.users, label: 'Patients' },
            { icon: Icons.megaphone, label: 'Campaigns' },
          ].map((n, i) => {
            const Icn = n.icon;
            return (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 11,
                padding: '8px 12px', borderRadius: 7, cursor: 'pointer',
                background: n.active ? T.sidebarActive : 'transparent',
                color: n.active ? '#fff' : T.sidebarText,
                fontSize: 13.5, fontWeight: n.active ? 500 : 400,
              }}>
                <Icn size={16} strokeWidth={1.5}/>
                <span style={{ flex: 1 }}>{n.label}</span>
                {n.badge ? (
                  <span style={{
                    fontSize: 11, padding: '1px 7px', borderRadius: 10,
                    background: n.active ? T.accent : 'rgba(255,255,255,0.1)',
                    color: '#fff', fontWeight: 600,
                  }}>{n.badge}</span>
                ) : null}
              </div>
            );
          })}

          <div style={{ marginTop: 20, padding: '8px 12px 6px', fontSize: 10, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '0.12em', fontWeight: 600 }}>Shared inboxes</div>
          {[
            { name: 'Front desk', dot: T.accent },
            { name: 'Billing', dot: '#A8782B' },
            { name: 'Dr. Lin (referrals)', dot: '#B85C3C' },
            { name: 'After-hours', dot: '#7A5C9A' },
          ].map((v, i) => (
            <div key={i} style={{
              padding: '7px 12px', fontSize: 12.5, color: 'rgba(255,255,255,0.6)',
              cursor: 'pointer', borderRadius: 7,
              display: 'flex', alignItems: 'center', gap: 9,
            }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: v.dot, display: 'inline-block' }}/>
              {v.name}
            </div>
          ))}
        </nav>

        <div style={{ padding: 12, borderTop: '1px solid rgba(255,255,255,0.06)', margin: '0 4px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 6 }}>
            <Avatar name="Jordan Kim" size={30} palette="B"/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ color: '#fff', fontSize: 12.5, fontWeight: 500 }}>Jordan Kim</div>
              <div style={{ color: 'rgba(255,255,255,0.45)', fontSize: 11 }}>Practice manager</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Thread list */}
      <div style={{
        width: 320, background: T.surface, borderRight: `1px solid ${T.border}`,
        display: 'flex', flexDirection: 'column', flexShrink: 0,
      }}>
        <div style={{ padding: '18px 20px 14px' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 14 }}>
            <h2 style={{ margin: 0, fontFamily: T.display, fontSize: 24, fontWeight: 500, color: T.text, letterSpacing: '-0.02em' }}>
              <span style={{ fontStyle: 'italic' }}>Today's</span> inbox
            </h2>
            <span style={{ fontSize: 11, color: T.textFaint, fontFamily: T.mono }}>Tue · May 22</span>
          </div>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px',
            background: T.surfaceAlt, borderRadius: 999,
          }}>
            <Icons.search size={13} stroke={T.textDim}/>
            <input placeholder="Search messages…" style={{
              border: 0, outline: 0, background: 'transparent', fontFamily: 'inherit',
              fontSize: 12.5, color: T.text, width: '100%',
            }}/>
          </div>
        </div>

        <div style={{ padding: '0 14px 10px', display: 'flex', gap: 5, flexWrap: 'wrap' }}>
          {[['Unread', 12, true],['Mine', 28],['Awaiting reply', 6],['Today', 14]].map(([l,n,a], i) => (
            <span key={i} style={{
              fontSize: 11, padding: '4px 10px', borderRadius: 999,
              background: a ? T.clay : 'transparent',
              color: a ? '#fff' : T.textDim,
              border: a ? 'none' : `1px solid ${T.border}`,
              cursor: 'pointer', fontWeight: a ? 600 : 500,
            }}>{l} · {n}</span>
          ))}
        </div>

        <div style={{ flex: 1, overflow: 'auto', padding: '0 8px 8px' }}>
          {WarmThreads.map((t) => (
            <div key={t.id} style={{
              display: 'flex', gap: 11, padding: '12px 12px',
              marginBottom: 2, borderRadius: 10, cursor: 'pointer',
              background: t.active ? T.surfaceAlt : 'transparent',
              position: 'relative',
            }}>
              <Avatar name={t.name} size={36} palette="B"/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 3 }}>
                  <span style={{ fontWeight: t.unread ? 600 : 500, fontSize: 13.5, color: T.text, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {t.name}
                  </span>
                  <span style={{ fontSize: 10.5, color: T.textFaint, fontFamily: T.mono }}>{t.time}</span>
                </div>
                <div style={{
                  fontSize: 12, color: t.unread ? T.text : T.textDim,
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                  lineHeight: 1.4, marginBottom: 5,
                }}>{t.preview}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <ChannelDot channel={t.channel} size={11}/>
                  {t.tag ? (
                    <span style={{ fontSize: 10.5, color: T.textDim, padding: '1px 7px', borderRadius: 999, background: T.surfaceAlt, border: `1px solid ${T.border}` }}>{t.tag}</span>
                  ) : null}
                  {t.ai ? <span style={{ fontSize: 10, color: T.accent, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 2 }}><Icons.sparkles size={10}/> Drafted</span> : null}
                  {t.flagged ? <Icons.flag size={11} stroke={T.clay}/> : null}
                </div>
              </div>
              {t.unread ? (
                <span style={{
                  position: 'absolute', top: 14, right: 12,
                  width: 8, height: 8, borderRadius: '50%', background: T.clay,
                }}/>
              ) : null}
            </div>
          ))}
        </div>
      </div>

      {/* Conversation */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: T.bg, minWidth: 0 }}>
        <div style={{
          padding: '16px 28px', display: 'flex', alignItems: 'center', gap: 14,
          background: T.surface, borderBottom: `1px solid ${T.border}`,
        }}>
          <Avatar name="Maya Okafor" size={42} palette="B"/>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: T.display, fontSize: 19, fontWeight: 500, color: T.text, letterSpacing: '-0.01em' }}>
              Maya Okafor
            </div>
            <div style={{ fontSize: 12, color: T.textDim, display: 'flex', alignItems: 'center', gap: 8, marginTop: 2 }}>
              <span style={{ color: T.accent }}>●</span> Online · SMS · (415) 555-0149 · Dr. Lin
            </div>
          </div>
          <div style={{ display: 'flex', gap: 4 }}>
            {[Icons.phone, Icons.calendar, Icons.star, Icons.more].map((Icn, i) => (
              <button key={i} style={{
                width: 34, height: 34, borderRadius: '50%', border: `1px solid ${T.border}`,
                background: T.surface, color: T.textDim, display: 'inline-flex',
                alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
              }}><Icn size={15}/></button>
            ))}
          </div>
        </div>

        <div style={{ flex: 1, overflow: 'auto', padding: '24px 32px', display: 'flex', flexDirection: 'column', gap: 16 }}>
          <WarmDateChip T={T} text="Yesterday"/>

          <WarmBubble T={T} from="patient" text="Hi! I had my 6-month checkup last week and just got the lab results in the portal. The cholesterol number looks a bit higher than last year — is that something we should chat about?" time="4:42 PM"/>

          <div style={{
            alignSelf: 'center', fontSize: 11.5, color: T.textDim,
            fontStyle: 'italic', fontFamily: T.display,
          }}>
            Dr. Lin reviewed labs · noted "Mild LDL increase, recommend dietary follow-up"
          </div>

          <WarmBubble T={T} from="staff" author="You" text="Hi Maya — totally normal to want to check in on that. Dr. Lin saw the labs and noted it's a mild increase, not urgent. We can either book a 15-min video follow-up next week, or revisit at your next physical in 6 months. What feels right?" time="6:48 PM"/>

          <WarmBubble T={T} from="patient" text="Let's do the video follow-up, that would put my mind at ease. Thursday afternoon could work?" time="7:01 PM"/>

          <WarmBubble T={T} from="staff" author="You" text="Booked you in for Thursday May 28 at 3:00 PM with Dr. Lin (video). Zoom link arrives 30 min before. Anything else?" time="7:04 PM"/>

          <WarmDateChip T={T} text="Today · 9:12 AM"/>

          <WarmBubble T={T} from="patient" text="Hi, can I move my Thursday 3pm? Something came up at work and I might not be home in time. Would 5:30 same day work?" time="9:12 AM" unread/>
        </div>

        {/* AI suggestion in clay accent */}
        <div style={{ margin: '0 28px 0' }}>
          <div style={{
            background: T.claySoft, borderRadius: 12, padding: '12px 14px',
            display: 'flex', alignItems: 'flex-start', gap: 12,
          }}>
            <div style={{
              width: 26, height: 26, borderRadius: '50%', background: T.clay, color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}><Icons.sparkles size={13}/></div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: T.clay, marginBottom: 4, letterSpacing: '0.05em', textTransform: 'uppercase' }}>Lumen drafted a reply</div>
              <div style={{ fontSize: 13.5, color: T.text, lineHeight: 1.55, fontFamily: T.display, fontStyle: 'italic' }}>
                "Of course Maya — I've moved you to Thu May 28 at 5:30 PM with Dr. Lin. A new Zoom link will arrive 30 min before. Let me know if anything else changes!"
              </div>
              <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
                <button style={{ fontSize: 12, padding: '5px 14px', borderRadius: 999, background: T.clay, color: '#fff', border: 'none', fontFamily: 'inherit', fontWeight: 500, cursor: 'pointer' }}>Send</button>
                <button style={{ fontSize: 12, padding: '5px 14px', borderRadius: 999, background: T.surface, color: T.text, border: `1px solid ${T.border}`, fontFamily: 'inherit', cursor: 'pointer' }}>Edit first</button>
                <button style={{ fontSize: 12, padding: '5px 14px', borderRadius: 999, background: 'transparent', color: T.textDim, border: 'none', fontFamily: 'inherit', cursor: 'pointer' }}>Not this time</button>
              </div>
            </div>
          </div>
        </div>

        <div style={{ padding: '14px 28px 22px' }}>
          <div style={{
            background: T.surface, borderRadius: 14, border: `1px solid ${T.border}`,
            padding: 4,
          }}>
            <div style={{ padding: '10px 14px 4px', display: 'flex', alignItems: 'center', gap: 6 }}>
              {[['SMS', true], ['WhatsApp'], ['Email']].map(([l, a], i) => (
                <button key={i} style={{
                  fontSize: 11.5, padding: '4px 11px', borderRadius: 999,
                  background: a ? T.accent : 'transparent',
                  color: a ? '#fff' : T.textDim,
                  border: a ? 'none' : `1px solid ${T.border}`,
                  cursor: 'pointer', fontFamily: 'inherit', fontWeight: a ? 600 : 500,
                }}>{l}</button>
              ))}
              <span style={{ marginLeft: 'auto', fontSize: 11, color: T.textFaint, fontFamily: T.mono }}>Auto-translate · ES</span>
            </div>
            <textarea placeholder="Reply to Maya, or press / for templates…" style={{
              width: '100%', border: 0, outline: 0, resize: 'none', background: 'transparent',
              padding: '6px 14px 10px', fontFamily: 'inherit', fontSize: 14, color: T.text,
              minHeight: 64, lineHeight: 1.5,
            }}/>
            <div style={{ display: 'flex', alignItems: 'center', padding: '6px 10px', borderTop: `1px solid ${T.border}` }}>
              <div style={{ display: 'flex', gap: 4 }}>
                {[Icons.paperclip, Icons.calendar, Icons.tag, Icons.sparkles].map((Icn, i) => (
                  <button key={i} style={{
                    width: 30, height: 30, borderRadius: 999, border: 'none',
                    background: 'transparent', color: T.textDim, cursor: 'pointer',
                    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  }}><Icn size={15}/></button>
                ))}
              </div>
              <button style={{
                marginLeft: 'auto', display: 'inline-flex', alignItems: 'center', gap: 7,
                padding: '8px 18px', background: T.text, color: T.surface, border: 'none',
                borderRadius: 999, fontFamily: 'inherit', fontSize: 12.5, fontWeight: 500, cursor: 'pointer',
              }}>Send <Icons.send size={13}/></button>
            </div>
          </div>
        </div>
      </div>

      {/* Patient panel */}
      <aside style={{
        width: 280, background: T.surface, borderLeft: `1px solid ${T.border}`,
        display: 'flex', flexDirection: 'column', flexShrink: 0, overflow: 'auto',
      }}>
        <div style={{ padding: '24px 20px 18px', textAlign: 'center' }}>
          <Avatar name="Maya Okafor" size={64} palette="B"/>
          <div style={{ fontFamily: T.display, fontSize: 19, fontWeight: 500, color: T.text, marginTop: 10, letterSpacing: '-0.01em' }}>Maya Okafor</div>
          <div style={{ fontSize: 12, color: T.textDim, marginTop: 2 }}>F · 34 · with you since 2017</div>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginTop: 12 }}>
            <span style={{ fontSize: 10, padding: '3px 8px', background: T.accentSoft, color: T.accent, borderRadius: 999, fontWeight: 600 }}>● Active</span>
            <span style={{ fontSize: 10, padding: '3px 8px', background: T.surfaceAlt, color: T.textDim, borderRadius: 999 }}>VIP</span>
          </div>
        </div>

        <div style={{ padding: '0 20px 18px' }}>
          <div style={{
            background: T.bg, borderRadius: 10, padding: 14,
            border: `1px solid ${T.border}`,
          }}>
            <div style={{ fontSize: 10, color: T.textDim, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase' }}>Coming up</div>
            <div style={{ fontFamily: T.display, fontSize: 15, fontWeight: 500, color: T.text, marginTop: 4 }}>
              Video follow-up with Dr. Lin
            </div>
            <div style={{ fontSize: 12, color: T.textDim, marginTop: 4 }}>
              Thu May 28 · 3:00 PM · 15 min
            </div>
            <div style={{
              fontSize: 11, color: T.clay, marginTop: 8, padding: 8,
              background: T.claySoft, borderRadius: 6,
            }}>
              Reschedule requested → 5:30 PM
            </div>
          </div>
        </div>

        <PanelSectionWarm title="Care timeline" T={T}>
          {[
            { date: 'Apr', label: 'Lab: lipid panel', dot: T.accent },
            { date: 'Apr', label: '6-mo checkup · Dr. Lin', dot: T.accent },
            { date: 'Nov 24', label: 'Annual physical', dot: T.textFaint },
            { date: 'Aug 24', label: 'Flu shot', dot: T.textFaint },
            { date: 'May 24', label: 'Telehealth · skin', dot: T.textFaint },
          ].map((t, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '5px 0' }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: t.dot, flexShrink: 0 }}/>
              <span style={{ fontSize: 11, color: T.textFaint, fontFamily: T.mono, width: 36, flexShrink: 0 }}>{t.date}</span>
              <span style={{ fontSize: 12.5, color: T.text }}>{t.label}</span>
            </div>
          ))}
        </PanelSectionWarm>

        <PanelSectionWarm title="Preferences" T={T}>
          <div style={{ fontSize: 12, lineHeight: 1.7, color: T.textDim }}>
            <div>SMS preferred · English</div>
            <div>Reminders 24h + 1h before</div>
            <div>PPO BlueShield · plan #4421</div>
          </div>
        </PanelSectionWarm>
      </aside>
    </div>
  );
}

function WarmBubble({ T, from, author, text, time, unread }) {
  const fromPatient = from === 'patient';
  return (
    <div style={{
      display: 'flex', flexDirection: 'column',
      alignItems: fromPatient ? 'flex-start' : 'flex-end', gap: 4,
    }}>
      <div style={{
        maxWidth: '72%',
        padding: '11px 15px',
        borderRadius: fromPatient ? '18px 18px 18px 4px' : '18px 18px 4px 18px',
        background: fromPatient ? T.surface : T.accent,
        color: fromPatient ? T.text : '#fff',
        fontSize: 14, lineHeight: 1.5,
        border: fromPatient ? `1px solid ${T.border}` : 'none',
        boxShadow: unread ? `0 0 0 2px ${T.claySoft}` : 'none',
      }}>
        {text}
      </div>
      <div style={{ fontSize: 10.5, color: T.textFaint, padding: '0 6px', fontFamily: T.mono }}>
        {fromPatient ? time : `${author} · ${time}`}
      </div>
    </div>
  );
}

function WarmDateChip({ T, text }) {
  return (
    <div style={{
      alignSelf: 'center', fontSize: 11, color: T.textDim,
      padding: '4px 14px', borderRadius: 999, background: T.surfaceAlt,
      fontFamily: T.display, fontStyle: 'italic',
    }}>{text}</div>
  );
}

function PanelSectionWarm({ title, children, T }) {
  return (
    <div style={{ padding: '14px 20px', borderTop: `1px solid ${T.border}` }}>
      <div style={{
        fontSize: 10, color: T.textDim, fontWeight: 600,
        textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 10,
      }}>{title}</div>
      {children}
    </div>
  );
}

window.InboxWarm = InboxWarm;
window.WarmTokens = WarmTokens;
