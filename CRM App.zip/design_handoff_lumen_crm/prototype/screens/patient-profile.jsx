// PatientProfile.jsx — Single patient record with unified timeline

function PatientProfile() {
  const T = ClinicalTokens;

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex',
      background: T.bg, fontFamily: T.font, color: T.text, fontSize: 13,
    }}>
      <ClinicalSidebar2 active="Patients"/>

      <div style={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column' }}>
        {/* breadcrumb */}
        <div style={{
          padding: '12px 32px', borderBottom: `1px solid ${T.border}`,
          background: T.surface, fontSize: 11.5, color: T.textDim, display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <span style={{ cursor: 'pointer' }}>Patients</span>
          <Icons.chevronRight size={11} stroke={T.textFaint}/>
          <span style={{ cursor: 'pointer' }}>Active · Maple</span>
          <Icons.chevronRight size={11} stroke={T.textFaint}/>
          <span style={{ color: T.text, fontWeight: 500 }}>Maya Okafor</span>
          <span style={{ marginLeft: 'auto', fontFamily: T.mono }}>MRN MO-4421</span>
        </div>

        {/* profile header */}
        <div style={{ padding: '24px 32px', background: T.surface, borderBottom: `1px solid ${T.border}` }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 18 }}>
            <Avatar name="Maya Okafor" size={72} palette="A"/>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                <h1 style={{ margin: 0, fontSize: 24, fontWeight: 600, letterSpacing: '-0.02em' }}>Maya Okafor</h1>
                <span style={{ fontSize: 11, padding: '3px 8px', borderRadius: 4, background: T.accentSoft, color: T.accent, fontWeight: 600 }}>Active</span>
                <span style={{ fontSize: 11, padding: '3px 8px', borderRadius: 4, background: '#F0EEE7', color: T.textDim, fontWeight: 500 }}>VIP</span>
                <span style={{ fontSize: 11, padding: '3px 8px', borderRadius: 4, background: '#F0EEE7', color: T.textDim, fontWeight: 500 }}>SMS opt-in</span>
              </div>
              <div style={{ display: 'flex', gap: 22, fontSize: 12.5, color: T.textDim }}>
                <div><span style={{ color: T.textFaint }}>DOB</span> Mar 04, 1991 <span style={{ color: T.textFaint }}>(34)</span></div>
                <div><span style={{ color: T.textFaint }}>Pronouns</span> she/her</div>
                <div><span style={{ color: T.textFaint }}>Provider</span> Dr. J. Lin</div>
                <div><span style={{ color: T.textFaint }}>Since</span> Mar 2017</div>
                <div><span style={{ color: T.textFaint }}>Phone</span> (415) 555-0149</div>
                <div><span style={{ color: T.textFaint }}>Email</span> maya.okafor@example.com</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <button style={primaryBtn(T)}><Icons.chat size={13}/> Message</button>
              <button style={secondaryBtn(T)}><Icons.calendar size={13}/> Book appt</button>
              <button style={iconBtnL2(T)}><Icons.more size={13}/></button>
            </div>
          </div>

          {/* mini-KPIs */}
          <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
            {[
              ['Lifetime visits', '14'],
              ['No-shows (12mo)', '0', T.success],
              ['Reply rate', '94%', T.success],
              ['Avg satisfaction', '9.2 / 10'],
              ['Outstanding balance', '$0.00', T.success],
              ['Last contact', '2m ago', T.accent],
            ].map(([l, v, c], i) => (
              <div key={i} style={{
                flex: 1, background: T.surfaceAlt, border: `1px solid ${T.border}`, borderRadius: 8,
                padding: '10px 12px',
              }}>
                <div style={{ fontSize: 10, color: T.textDim, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 3 }}>{l}</div>
                <div style={{ fontSize: 17, fontWeight: 600, color: c || T.text, fontFamily: T.mono, letterSpacing: '-0.01em' }}>{v}</div>
              </div>
            ))}
          </div>
        </div>

        {/* tabs + content */}
        <div style={{ background: T.surface, borderBottom: `1px solid ${T.border}`, padding: '0 32px', display: 'flex', gap: 18 }}>
          {['Timeline', 'Messages', 'Appointments', 'Labs', 'Billing', 'Notes', 'Files'].map((tab, i) => (
            <div key={i} style={{
              padding: '10px 0', fontSize: 12.5, color: i === 0 ? T.text : T.textDim,
              fontWeight: i === 0 ? 600 : 500, cursor: 'pointer',
              borderBottom: i === 0 ? `2px solid ${T.accent}` : '2px solid transparent',
              marginBottom: -1,
            }}>
              {tab}
              {tab === 'Messages' ? <span style={{ marginLeft: 6, fontSize: 10, padding: '1px 6px', borderRadius: 8, background: T.accentSoft, color: T.accent, fontFamily: T.mono }}>3</span> : null}
            </div>
          ))}
        </div>

        <div style={{ flex: 1, padding: '24px 32px', display: 'grid', gridTemplateColumns: '1fr 320px', gap: 20 }}>
          {/* Timeline */}
          <div>
            <ProfileTimeline T={T}/>
          </div>

          {/* Right column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <ProfileCard T={T} title="Care team">
              {[
                { name: 'Dr. Jenna Lin, MD', role: 'Primary care', initials: 'JL' },
                { name: 'Nurse Lúcia Ortega', role: 'Care coordinator', initials: 'LO' },
                { name: 'Jordan Kim', role: 'Practice manager', initials: 'JK' },
              ].map((p, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 0' }}>
                  <Avatar name={p.name} size={28} palette="A"/>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 500 }}>{p.name}</div>
                    <div style={{ fontSize: 11, color: T.textFaint }}>{p.role}</div>
                  </div>
                  <button style={{ fontSize: 11, color: T.accent, background: 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontWeight: 600 }}>Message</button>
                </div>
              ))}
            </ProfileCard>

            <ProfileCard T={T} title="Insurance & billing">
              <div style={{ fontSize: 12.5, lineHeight: 1.7 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: T.textDim }}>Plan</span>
                  <span style={{ fontWeight: 500 }}>PPO BlueShield Gold</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: T.textDim }}>Member ID</span>
                  <span style={{ fontFamily: T.mono }}>BS-4421-A09</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: T.textDim }}>Copay</span>
                  <span style={{ fontFamily: T.mono }}>$25</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: T.textDim }}>Eligibility</span>
                  <span style={{ color: T.success, fontWeight: 600 }}>● Verified</span>
                </div>
              </div>
            </ProfileCard>

            <ProfileCard T={T} title="Pinned notes">
              <div style={{
                fontSize: 12, color: T.text, lineHeight: 1.55,
                padding: 10, background: '#FBF6EC', border: `1px solid #F0E4C9`, borderRadius: 6,
              }}>
                <div style={{ fontSize: 10, color: T.warn, fontWeight: 600, marginBottom: 3 }}>⚠ ALERT</div>
                Allergic to penicillin (anaphylaxis 2018). Use cephalosporins with caution.
              </div>
              <div style={{ fontSize: 12, color: T.textDim, marginTop: 10, lineHeight: 1.55 }}>
                Prefers SMS for routine communication. Worked overnight shifts Apr–May, schedule accordingly.
              </div>
            </ProfileCard>

            <ProfileCard T={T} title="Tags">
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                {['Preventive', 'Email opt-in', 'SMS preferred', 'Annual labs', 'PPO BlueShield', 'Couples care'].map((t, i) => (
                  <span key={i} style={{
                    fontSize: 11, padding: '3px 8px', borderRadius: 4,
                    background: T.surfaceAlt, border: `1px solid ${T.border}`, color: T.textDim,
                  }}>{t}</span>
                ))}
                <button style={{
                  fontSize: 11, padding: '3px 8px', borderRadius: 4, background: 'transparent',
                  color: T.textFaint, border: `1px dashed ${T.border}`, cursor: 'pointer', fontFamily: 'inherit',
                }}>+ Add</button>
              </div>
            </ProfileCard>
          </div>
        </div>
      </div>
    </div>
  );
}

function ProfileTimeline({ T }) {
  const events = [
    { type: 'message', who: 'patient', time: 'Today 9:12 AM', text: 'Hi, can I move my Thursday 3pm? Something came up at work and I might not be home in time. Would 5:30 same day work?', channel: 'sms', urgent: true },
    { type: 'system', time: 'Today 9:13 AM', text: 'Lumen drafted a reply · moves appt to Thu 5:30 PM', icon: 'ai' },
    { type: 'message', who: 'staff', author: 'You', time: 'Yesterday 7:04 PM', text: 'Booked you for Thu May 28 at 3:00 PM with Dr. Lin (video). Zoom link 30 min before.', channel: 'sms' },
    { type: 'appt', time: 'Yesterday 7:04 PM', text: 'Video follow-up booked', detail: 'Thu May 28 · 3:00 PM · Dr. Lin · 15min' },
    { type: 'note', time: 'Yesterday 6:10 PM', text: 'Dr. Lin · Mild LDL increase, recommend dietary follow-up in 3mo', author: 'Dr. Lin' },
    { type: 'message', who: 'patient', time: 'Yesterday 4:42 PM', text: 'Hi! I had my 6-month checkup last week and just got the lab results...', channel: 'sms' },
    { type: 'lab', time: 'May 16', text: 'Lipid panel results released to portal', detail: 'LDL 142 mg/dL · slight elevation' },
    { type: 'appt', time: 'May 14', text: '6-month checkup completed', detail: 'Dr. Lin · 30min · BP 118/76' },
    { type: 'campaign', time: 'May 12', text: 'Pre-visit reminder sent', detail: 'Campaign: Annual Labs Spring 2026 · clicked link' },
    { type: 'message', who: 'system', time: 'Apr 03', text: 'Appointment confirmation auto-sent', channel: 'sms' },
  ];
  const typeMeta = {
    message: { color: T.accent, label: 'Message' },
    system: { color: T.textFaint, label: 'System' },
    appt: { color: '#5B8C5A', label: 'Appointment' },
    note: { color: T.warn, label: 'Clinical note' },
    lab: { color: '#7A5C9A', label: 'Lab' },
    campaign: { color: '#A85C8C', label: 'Campaign' },
  };
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: 12, gap: 8 }}>
        <h2 style={{ margin: 0, fontSize: 16, fontWeight: 600, color: T.text }}>Unified timeline</h2>
        <span style={{ fontSize: 11.5, color: T.textDim }}>Everything in one place — messages, appts, labs, notes, campaigns</span>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
          {['All', 'Messages', 'Clinical', 'Billing'].map((t, i) => (
            <span key={i} style={{
              fontSize: 11, padding: '3px 9px', borderRadius: 5,
              background: i === 0 ? T.accentSoft : 'transparent',
              color: i === 0 ? T.accent : T.textDim,
              border: `1px solid ${i === 0 ? T.accentSoft : T.border}`,
              cursor: 'pointer', fontWeight: i === 0 ? 600 : 500,
            }}>{t}</span>
          ))}
        </div>
      </div>

      <div style={{
        background: T.surface, border: `1px solid ${T.border}`, borderRadius: 12, padding: '8px 0',
      }}>
        {events.map((e, i) => {
          const meta = typeMeta[e.type];
          const isLast = i === events.length - 1;
          return (
            <div key={i} style={{ display: 'flex', gap: 14, padding: '12px 18px', position: 'relative' }}>
              {/* dot + line */}
              <div style={{ position: 'relative', width: 12, flexShrink: 0 }}>
                <span style={{
                  position: 'absolute', top: 4, left: 0, width: 10, height: 10,
                  borderRadius: '50%', background: meta.color, border: `2px solid ${T.surface}`,
                  boxShadow: `0 0 0 1px ${T.border}`,
                }}/>
                {!isLast ? (
                  <span style={{
                    position: 'absolute', top: 16, bottom: -12, left: 4,
                    width: 2, background: T.border,
                  }}/>
                ) : null}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 3 }}>
                  <span style={{ fontSize: 10, color: meta.color, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    {meta.label}
                  </span>
                  {e.urgent ? <span style={{ fontSize: 9.5, padding: '0 5px', borderRadius: 3, background: '#FBE8E5', color: T.danger, fontFamily: T.mono, fontWeight: 600 }}>UNREAD</span> : null}
                  {e.channel ? <ChannelDot channel={e.channel} size={10}/> : null}
                  {e.author ? <span style={{ fontSize: 11, color: T.textDim }}>· {e.author}</span> : null}
                  <span style={{ marginLeft: 'auto', fontSize: 10.5, color: T.textFaint, fontFamily: T.mono }}>{e.time}</span>
                </div>
                <div style={{
                  fontSize: 13, color: T.text, lineHeight: 1.5,
                  padding: e.type === 'message' ? '8px 12px' : 0,
                  background: e.type === 'message' ? (e.who === 'staff' ? T.accentSoft : T.surfaceAlt) : 'transparent',
                  borderRadius: e.type === 'message' ? 7 : 0,
                  border: e.type === 'message' ? `1px solid ${e.who === 'staff' ? T.accentSoft : T.border}` : 'none',
                }}>
                  {e.text}
                </div>
                {e.detail ? <div style={{ fontSize: 11.5, color: T.textDim, marginTop: 4 }}>{e.detail}</div> : null}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ProfileCard({ T, title, children }) {
  return (
    <div style={{ background: T.surface, border: `1px solid ${T.border}`, borderRadius: 10, padding: '14px 16px' }}>
      <div style={{ fontSize: 11, color: T.textDim, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>{title}</div>
      {children}
    </div>
  );
}

function primaryBtn(T) {
  return {
    padding: '8px 14px', borderRadius: 7, background: T.accent, color: '#fff',
    border: 'none', fontFamily: 'inherit', fontSize: 12.5, fontWeight: 600, cursor: 'pointer',
    display: 'inline-flex', alignItems: 'center', gap: 6,
  };
}
function secondaryBtn(T) {
  return {
    padding: '8px 14px', borderRadius: 7, background: T.surface, color: T.text,
    border: `1px solid ${T.border}`, fontFamily: 'inherit', fontSize: 12.5, fontWeight: 500, cursor: 'pointer',
    display: 'inline-flex', alignItems: 'center', gap: 6,
  };
}
function iconBtnL2(T) {
  return {
    width: 34, height: 34, borderRadius: 7, border: `1px solid ${T.border}`,
    background: T.surface, color: T.textDim,
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
  };
}

window.PatientProfile = PatientProfile;
