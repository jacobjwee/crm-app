// app.jsx — mounts the design canvas with all artboards

function Placeholder({ label, note }) {
  return (
    <div style={{
      width: '100%', height: '100%',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      background: 'repeating-linear-gradient(135deg, #f6f5f1, #f6f5f1 18px, #efece5 18px, #efece5 36px)',
      color: '#5C6470', fontFamily: "'Geist Mono', ui-monospace, monospace", gap: 6,
    }}>
      <div style={{ fontSize: 14, fontWeight: 600, color: '#0F1419', letterSpacing: '-0.01em' }}>{label}</div>
      {note ? <div style={{ fontSize: 11.5 }}>{note}</div> : null}
    </div>
  );
}

const W = 1440, H = 900;

function App() {
  return (
    <DesignCanvas
      title="Lumen · Messaging-first clinic CRM"
      subtitle="Three Inbox directions side-by-side, then full product in the chosen system">
      <DCSection id="inbox" title="Inbox — three directions" subtitle="The hero surface. Pick the visual system, full product below is in Direction A.">
        <DCArtboard id="inbox-a" label="A · Clinical Calm" width={W} height={H}>
          <InboxClinical/>
        </DCArtboard>
        <DCArtboard id="inbox-b" label="B · Warm Practice" width={W} height={H}>
          <InboxWarm/>
        </DCArtboard>
        <DCArtboard id="inbox-c" label="C · Dense Pro" width={W} height={H}>
          <InboxDense/>
        </DCArtboard>
      </DCSection>

      <DCSection id="product" title="Direction A · full product" subtitle="Same system applied across the rest of the surfaces.">
        <DCArtboard id="dashboard" label="Dashboard" width={W} height={H}>
          {typeof Dashboard !== 'undefined' ? <Dashboard/> : <Placeholder label="Dashboard" note="coming next"/>}
        </DCArtboard>
        <DCArtboard id="calendar" label="Calendar & scheduling" width={W} height={H}>
          {typeof Calendar !== 'undefined' ? <Calendar/> : <Placeholder label="Calendar" note="coming next"/>}
        </DCArtboard>
        <DCArtboard id="profile" label="Patient profile" width={W} height={H}>
          {typeof PatientProfile !== 'undefined' ? <PatientProfile/> : <Placeholder label="Patient profile" note="coming next"/>}
        </DCArtboard>
        <DCArtboard id="patients" label="Patient list & segments" width={W} height={H}>
          {typeof PatientList !== 'undefined' ? <PatientList/> : <Placeholder label="Patient list" note="coming next"/>}
        </DCArtboard>
        <DCArtboard id="campaigns" label="Campaigns" width={W} height={H}>
          {typeof Campaigns !== 'undefined' ? <Campaigns/> : <Placeholder label="Campaigns" note="coming next"/>}
        </DCArtboard>
        <DCArtboard id="settings" label="Settings" width={W} height={H}>
          {typeof Settings !== 'undefined' ? <Settings/> : <Placeholder label="Settings" note="coming next"/>}
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
