// PatientList.jsx — Patient list with segments / saved views

const PatientRows = [
  { n: 'Maya Okafor', mrn: 'MO-4421', a: 34, p: 'Dr. Lin', last: '2m', next: 'Thu May 28', stat: 'Active', tags: ['VIP', 'Annual labs'], ltv: 3820, ns: 0 },
  { n: 'Daniel Reyes', mrn: 'DR-3018', a: 52, p: 'Dr. Lin', last: '9m', next: 'Wed May 21', stat: 'Active', tags: ['Pre-visit'], ltv: 2210, ns: 1 },
  { n: 'Aisha Patel', mrn: 'AP-5552', a: 28, p: 'Dr. Lin', last: '14m', next: 'Tue May 22', stat: 'New', tags: ['Intake'], ltv: 0, ns: 0 },
  { n: 'Greg Hollister', mrn: 'GH-1109', a: 61, p: 'Dr. Park', last: '22m', next: '—', stat: 'Active', tags: ['Billing'], ltv: 5400, ns: 0 },
  { n: 'Sofia Bianchi', mrn: 'SB-2274', a: 39, p: 'Dr. Lin', last: '38m', next: 'Jun 10', stat: 'Active', tags: ['Follow-up'], ltv: 1840, ns: 0 },
  { n: 'Marcus Lin', mrn: 'ML-9930', a: 45, p: 'Dr. Park', last: '1h', next: 'Reschedule?', stat: 'At risk', tags: ['No-show'], ltv: 2640, ns: 3 },
  { n: 'Priya Ramaswamy', mrn: '—', a: 31, p: '—', last: '2h', next: '—', stat: 'New lead', tags: ['Voicemail'], ltv: 0, ns: 0 },
  { n: 'Owen Carter', mrn: 'OC-3367', a: 8, p: 'Dr. Park', last: '3h', next: 'Mon May 26', stat: 'Active', tags: ['Pediatric'], ltv: 920, ns: 0 },
  { n: 'Rebecca Wu', mrn: 'RW-7781', a: 47, p: 'Dr. Lin', last: '4h', next: 'Jun 02', stat: 'Active', tags: ['Forms'], ltv: 4120, ns: 0 },
  { n: 'Hugo Pereira', mrn: 'HP-1188', a: 58, p: 'Dr. Lin', last: '6h', next: 'Jun 14', stat: 'Active', tags: ['Rx renewal', 'Chronic'], ltv: 6210, ns: 0 },
  { n: 'Carla Mendes', mrn: 'CM-2261', a: 26, p: 'Dr. Park', last: 'Yest.', next: 'Wed May 21', stat: 'Active', tags: ['Reschedule'], ltv: 740, ns: 0 },
  { n: 'Tomás Okafor', mrn: 'TO-4422', a: 36, p: 'Dr. Lin', last: '2d', next: 'Jun 08', stat: 'Active', tags: ['Spouse-of'], ltv: 2240, ns: 0 },
  { n: 'Lara Petrov', mrn: 'LP-6691', a: 67, p: 'Dr. Park', last: '4d', next: 'Waitlist', stat: 'Waitlist', tags: ['Medicare'], ltv: 8120, ns: 1 },
  { n: 'Sam Chen', mrn: 'SC-0042', a: 6, p: 'Dr. Park', last: '5d', next: 'Tue May 22', stat: 'Active', tags: ['Pediatric', 'Guardian'], ltv: 410, ns: 0 },
  { n: 'Hannah Wright', mrn: 'HW-3344', a: 41, p: 'Dr. Lin', last: '1w', next: 'Reschedule?', stat: 'At risk', tags: ['No-show'], ltv: 1880, ns: 2 },
  { n: 'Isabel Park', mrn: 'IP-7820', a: 33, p: 'Dr. Park', last: '2w', next: '—', stat: 'Dormant', tags: ['Re-engage'], ltv: 980, ns: 0 },
];

const Segments = [
  { name: 'All patients', count: 2841, active: false },
  { name: 'Active · last 90d', count: 1842, active: true },
  { name: 'New this month', count: 47, dot: '#5B8C5A' },
  { name: 'At no-show risk', count: 23, dot: '#C3463A' },
  { name: 'Dormant 6+ mo', count: 412, dot: '#A8782B' },
  { name: 'Birthday this week', count: 18, dot: '#A85C8C' },
  { name: 'Annual physical due', count: 142, dot: '#7A5C9A' },
  { name: 'Outstanding balance', count: 34, dot: '#C3463A' },
  { name: 'Spanish-preferred', count: 218, dot: '#5B8C5A' },
  { name: 'Pediatric', count: 386, dot: '#2E8C82' },
  { name: 'VIP', count: 64, dot: '#A85C8C' },
];

function PatientList() {
  const T = ClinicalTokens;
  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex',
      background: T.bg, fontFamily: T.font, color: T.text, fontSize: 13,
    }}>
      <ClinicalSidebar2 active="Patients"/>

      {/* segments rail */}
      <aside style={{
        width: 240, background: T.surface, borderRight: `1px solid ${T.border}`,
        display: 'flex', flexDirection: 'column', flexShrink: 0,
      }}>
        <div style={{ padding: '20px 18px 12px' }}>
          <div style={{ fontSize: 11, color: T.textDim, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>Segments</div>
          <button style={{
            width: '100%', padding: '7px 10px', borderRadius: 7, border: `1px dashed ${T.borderStrong}`,
            background: 'transparent', color: T.text, fontFamily: 'inherit', fontSize: 12, fontWeight: 500,
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'center',
          }}><Icons.plus size={12} strokeWidth={2}/> New segment</button>
        </div>
        <div style={{ flex: 1, overflow: 'auto', padding: '4px 8px' }}>
          {Segments.map((s, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px',
              borderRadius: 6, cursor: 'pointer',
              background: s.active ? T.accentSoft : 'transparent',
              color: s.active ? T.text : T.textDim,
              fontSize: 12.5, fontWeight: s.active ? 600 : 400,
              borderLeft: s.active ? `2px solid ${T.accent}` : '2px solid transparent',
              marginLeft: s.active ? -2 : 0,
            }}>
              {s.dot ? <span style={{ width: 7, height: 7, borderRadius: '50%', background: s.dot }}/> : <span style={{ width: 7 }}/>}
              <span style={{ flex: 1 }}>{s.name}</span>
              <span style={{ fontSize: 10.5, color: s.active ? T.accent : T.textFaint, fontFamily: T.mono }}>{s.count.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </aside>

      {/* main */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <div style={{
          padding: '20px 32px 14px', background: T.surface, borderBottom: `1px solid ${T.border}`,
        }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, marginBottom: 14 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11.5, color: T.textDim, fontFamily: T.mono, marginBottom: 4 }}>SEGMENT</div>
              <h1 style={{ margin: 0, fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em' }}>Active · last 90d</h1>
              <div style={{ fontSize: 12, color: T.textDim, marginTop: 4 }}>1,842 patients · updated 4m ago</div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button style={secondaryBtnL(T)}><Icons.tag size={13}/> Bulk tag</button>
              <button style={secondaryBtnL(T)}><Icons.megaphone size={13}/> Create campaign</button>
              <button style={primaryBtnL(T)}><Icons.chat size={13}/> Message segment</button>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{
              flex: 1, display: 'flex', alignItems: 'center', gap: 8, padding: '7px 12px',
              background: T.surfaceAlt, border: `1px solid ${T.border}`, borderRadius: 7,
            }}>
              <Icons.search size={13} stroke={T.textFaint}/>
              <input placeholder="Filter patients · try “no-show > 1 AND last visit > 90d”" style={{
                flex: 1, border: 0, outline: 0, background: 'transparent',
                fontFamily: 'inherit', fontSize: 12.5, color: T.text,
              }}/>
            </div>
            {['Age 25–45', 'Dr. Lin', 'SMS opt-in', 'Has insurance'].map((f, i) => (
              <span key={i} style={{
                display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11.5,
                padding: '4px 9px', borderRadius: 5,
                background: T.accentSoft, color: T.accent, border: `1px solid ${T.accentSoft}`, fontWeight: 500,
              }}>{f} <span style={{ color: T.accent, opacity: 0.6 }}>×</span></span>
            ))}
            <button style={{
              fontSize: 11.5, padding: '4px 9px', borderRadius: 5,
              background: 'transparent', color: T.textDim, border: `1px dashed ${T.border}`,
              cursor: 'pointer', fontFamily: 'inherit',
            }}>+ Add filter</button>
          </div>
        </div>

        {/* Table */}
        <div style={{ flex: 1, overflow: 'auto', background: T.surface }}>
          <table style={{
            width: '100%', borderCollapse: 'collapse', fontSize: 12.5,
          }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${T.border}`, background: T.surfaceAlt }}>
                {[
                  ['', 32],
                  ['Patient', null],
                  ['MRN', 90],
                  ['Provider', 100],
                  ['Last contact', 100],
                  ['Next appt', 110],
                  ['Status', 90],
                  ['Tags', null],
                  ['LTV', 80],
                  ['NS', 50],
                  ['', 70],
                ].map(([l, w], i) => (
                  <th key={i} style={{
                    textAlign: i >= 8 && i < 10 ? 'right' : 'left',
                    padding: '10px 14px',
                    fontSize: 10.5, color: T.textDim, fontWeight: 600,
                    textTransform: 'uppercase', letterSpacing: '0.05em',
                    width: w || undefined,
                  }}>{l}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {PatientRows.map((p, i) => {
                const statColor = {
                  'Active': T.success,
                  'New': T.accent,
                  'New lead': T.accent,
                  'At risk': T.danger,
                  'Waitlist': T.warn,
                  'Dormant': T.textFaint,
                }[p.stat];
                return (
                  <tr key={i} style={{
                    borderBottom: `1px solid ${T.border}`,
                    background: i % 2 ? T.surface : T.surfaceAlt,
                  }}>
                    <td style={{ padding: '10px 14px' }}>
                      <input type="checkbox" style={{ accentColor: T.accent }}/>
                    </td>
                    <td style={{ padding: '10px 14px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                        <Avatar name={p.n} size={28} palette="A"/>
                        <div>
                          <div style={{ fontWeight: 500 }}>{p.n}</div>
                          <div style={{ fontSize: 10.5, color: T.textFaint }}>{p.a} · {p.tags.includes('Pediatric') ? 'pediatric' : (p.a > 60 ? 'senior' : 'adult')}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{ padding: '10px 14px', fontFamily: T.mono, fontSize: 11.5, color: T.textDim }}>{p.mrn}</td>
                    <td style={{ padding: '10px 14px', color: T.textDim }}>{p.p}</td>
                    <td style={{ padding: '10px 14px', fontFamily: T.mono, fontSize: 11.5, color: T.textDim }}>{p.last}</td>
                    <td style={{ padding: '10px 14px', color: p.next.includes('Reschedule') ? T.warn : T.text, fontWeight: p.next === '—' ? 400 : 500, fontSize: 12 }}>{p.next}</td>
                    <td style={{ padding: '10px 14px' }}>
                      <span style={{
                        fontSize: 10.5, padding: '2px 8px', borderRadius: 4,
                        background: statColor === T.success ? T.accentSoft : statColor === T.danger ? '#FBE8E5' : statColor === T.warn ? '#FBF6EC' : statColor === T.accent ? T.accentSoft : '#F0EEE7',
                        color: statColor, fontWeight: 600,
                      }}>{p.stat}</span>
                    </td>
                    <td style={{ padding: '10px 14px' }}>
                      <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
                        {p.tags.slice(0, 2).map((t, j) => (
                          <span key={j} style={{
                            fontSize: 10, padding: '1px 6px', borderRadius: 3,
                            background: T.surfaceAlt, border: `1px solid ${T.border}`, color: T.textDim,
                          }}>{t}</span>
                        ))}
                      </div>
                    </td>
                    <td style={{ padding: '10px 14px', textAlign: 'right', fontFamily: T.mono, fontSize: 11.5 }}>
                      ${p.ltv.toLocaleString()}
                    </td>
                    <td style={{ padding: '10px 14px', textAlign: 'right', fontFamily: T.mono, fontSize: 11.5, color: p.ns > 1 ? T.danger : p.ns === 1 ? T.warn : T.textFaint }}>
                      {p.ns}
                    </td>
                    <td style={{ padding: '10px 14px' }}>
                      <div style={{ display: 'flex', gap: 4 }}>
                        <button style={{
                          padding: '4px 8px', borderRadius: 5, background: 'transparent',
                          color: T.accent, border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontSize: 11, fontWeight: 600,
                          display: 'inline-flex', alignItems: 'center', gap: 3,
                        }}><Icons.chat size={11}/> Msg</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* footer */}
        <div style={{
          padding: '10px 32px', borderTop: `1px solid ${T.border}`, background: T.surface,
          display: 'flex', alignItems: 'center', fontSize: 11.5, color: T.textDim,
        }}>
          <span>Showing 16 of 1,842 · 0 selected</span>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
            <button style={iconBtnL3(T)}><Icons.chevronLeft size={11}/></button>
            <span style={{ padding: '4px 10px', fontFamily: T.mono }}>1 of 116</span>
            <button style={iconBtnL3(T)}><Icons.chevronRight size={11}/></button>
          </div>
        </div>
      </div>
    </div>
  );
}

function primaryBtnL(T) {
  return {
    padding: '8px 14px', borderRadius: 7, background: T.accent, color: '#fff',
    border: 'none', fontFamily: 'inherit', fontSize: 12.5, fontWeight: 600, cursor: 'pointer',
    display: 'inline-flex', alignItems: 'center', gap: 6,
  };
}
function secondaryBtnL(T) {
  return {
    padding: '8px 14px', borderRadius: 7, background: T.surface, color: T.text,
    border: `1px solid ${T.border}`, fontFamily: 'inherit', fontSize: 12.5, fontWeight: 500, cursor: 'pointer',
    display: 'inline-flex', alignItems: 'center', gap: 6,
  };
}
function iconBtnL3(T) {
  return {
    width: 26, height: 26, borderRadius: 5, border: `1px solid ${T.border}`,
    background: T.surface, color: T.textDim, display: 'inline-flex',
    alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
  };
}

window.PatientList = PatientList;
