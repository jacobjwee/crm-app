# Handoff: Lumen — Messaging-first clinic CRM

## Overview
A redesign of the existing CRM app into a **messaging-first clinic CRM and patient engagement platform** for independent clinics. The hero surface is a unified inbox (SMS / WhatsApp / Email / Voice / in-app chat) tightly integrated with appointment scheduling, a patient CRM record, segments, broadcast campaigns, and clinic settings. The system is built to evolve from the current product's dark-sidebar / light-surface idiom and keep the "CRM App" mark intact.

## About the design files
The files in `prototype/` are **design references created in HTML/JSX** — interactive prototypes showing the intended look, layout, and behavior. They are **not production code to copy directly**. The task is to **recreate these designs in the target codebase's existing environment** (likely React + the existing component library and styling approach) using its established patterns. Token values, copy, and layout specs in this README are authoritative; the HTML is the visual reference.

If the existing codebase has a design system, prefer its primitives (Button, Card, Avatar, etc.) and substitute the token values below into its theme.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, iconography, copy, and component shapes are intended to be reproduced pixel-close. Three visual directions are included for the **Inbox** (the hero surface) — see "Direction choice" below. The full product surfaces (Dashboard, Calendar, Patient profile, Patient list, Campaigns, Settings) are designed in **Direction A · Clinical Calm**, which is the recommended path because it is a direct evolution of the current CRM app.

---

## Direction choice — Inbox

Three side-by-side directions live in the canvas. Pick one before implementing the rest of the product surfaces.

| Direction | Feel | Sidebar | Surface | Accent | Type |
|---|---|---|---|---|---|
| **A · Clinical Calm** *(recommended)* | Calm, trustworthy, conservative | Deep navy `#0E1622` | Warm off-white `#F6F5F1` | Teal `#2E8C82` | Geist + Geist Mono |
| **B · Warm Practice** | Friendly, human, distinctive | Deep brown `#2A2218` | Cream `#FBF7EE` | Sage `#5C7A4F`, clay `#B85C3C` | DM Sans + Newsreader (serif accents) |
| **C · Dense Pro** | Power-user, keyboard-first, Linear-like | Dark `#0B0D11` | Dark `#12151B` | Ice blue `#7BB5F5` | IBM Plex Sans + Mono |

The remaining product screens are built in Direction A. If you pick B or C, the same layouts apply — swap the token values listed under that direction.

---

## Design tokens — Direction A (Clinical Calm)

### Color
```
/* Surfaces */
bg               #F6F5F1   warm off-white page background
surface          #FFFFFF   cards, surfaces, conversation pane
surface-alt      #FAF9F5   subtle alt surface (sidebars, hover)
border           #E7E4DC   1px borders, dividers
border-strong    #D9D5CB   stronger borders (composer)

/* Text */
text             #0F1419   primary text
text-dim         #5C6470   secondary text
text-faint       #94A0AE   tertiary text, timestamps

/* Sidebar (dark) */
sidebar-bg       #0E1622
sidebar-text     rgba(255,255,255,0.7)
sidebar-text-active  #FFFFFF
sidebar-hover    rgba(255,255,255,0.06)
sidebar-active   rgba(83,178,168,0.18)

/* Accent + status */
accent           #2E8C82   primary teal (buttons, active states, send)
accent-soft      #E5F1EF   accent backgrounds, AI suggestion strip
success          #3E8C5A
warn             #B6792B
danger           #C3463A

/* Channel chips */
sms              bg #DBEAFE  fg #1E40AF
whatsapp         bg #D1FAE5  fg #065F46
email            bg #EDE9FE  fg #5B21B6
chat             bg #FEF3C7  fg #92400E
voice            bg #FEE2E2  fg #991B1B
```

### Typography
- **Body / UI**: `'Geist', system-ui, sans-serif`. Weights 300, 400, 500, 600, 700. `font-feature-settings: "cv11", "ss01"`.
- **Mono / numerals / IDs / timestamps**: `'Geist Mono', ui-monospace, monospace`. Weights 400, 500.
- **Type scale (rem at 16px base)**:
  - `xs` 10–10.5px — uppercase labels, kbd shortcuts
  - `sm` 11–11.5px — meta, captions, timestamps
  - `base` 12.5–13px — body, table rows, secondary headlines
  - `md` 13.5–14px — message bubbles, primary body
  - `lg` 15–17px — card titles, patient name
  - `xl` 22–24px — page titles
  - `display` 28px — KPI numbers (mono)
- **Letter-spacing**: `-0.02em` on large display numbers and page titles; `-0.01em` on patient/card titles; `0.05–0.08em uppercase` on overline labels.
- **Line-height**: 1.5–1.55 for body, 1.25 for KPI numbers, 1.4 for table rows.

### Spacing
4px base. Common values: 4, 6, 8, 10, 12, 14, 16, 18, 22, 28, 32. Cards usually `padding: 14–18px`; main content `padding: 24–32px`. Sidebar nav rows `padding: 7px 10px`.

### Radius
- 4–5px — pills, small chips, badges, tag chips
- 6–7px — buttons, search inputs, icon buttons
- 8–10px — cards, message bubbles (asymmetric corners on bubbles)
- 12px — major card containers (dashboard tiles, builder blocks)
- 50% — avatars, status dots, AI sparkle badge
- Message bubbles: patient `14px 14px 14px 4px`, staff `14px 14px 4px 14px`

### Shadow
Very subtle — most depth comes from 1px borders.
- Cards: `0 1px 2px rgba(0,0,0,0.04)` (optional, only on interactive surfaces)
- Focus glows: `box-shadow: 0 0 0 2px {accent-soft}`

### Iconography
- Custom 20×20 viewBox, 1.5px stroke, `stroke-linecap: round`, `stroke-linejoin: round`. See `prototype/system.jsx` for the full set (inbox, chat, calendar, users, megaphone, dashboard, settings, search, send, paperclip, plus, chevrons, more, star, bell, filter, phone, mail, sms, whatsapp, check, checkCircle, clock, sparkles, bolt, tag, archive, trash, edit, link, pin, flag).
- Channel chips: small rounded square `20×20` with the channel icon, channel-specific bg/fg from the color table above.
- Never use emoji as iconography. The current product's emoji KPI icons should be replaced.

### Avatars
- Circular, initial-based, sized 28 / 32 / 36 / 56 / 72.
- Background color derived deterministically from the patient name (hash to hue) using `oklch(0.78 0.06 <hue>)` for Direction A (light pastel). Text is `#1a1410`, weight 600, ~36% of avatar size.

---

## Sidebar (global)

Width **220px**, background `sidebar-bg`, flex column, full-height.

1. **Brand block** (padding `20 18 24`):
   - 22×22 rounded-6 tile, bg `accent`, contains capital "L" in `#0E1622` weight 800 size 13
   - "Lumen" in white weight 600 + "CRM" in `rgba(255,255,255,0.4)` size 12
2. **New message button** (`8 10`, full-width, radius 7): bg `rgba(255,255,255,0.08)`, border `1px solid rgba(255,255,255,0.06)`, `+` icon + label + right-aligned `⌘N` kbd.
3. **Nav rows** (padding `7 10`, radius 6):
   - Icon 16px stroke 1.6, label 13.5px, badge (mono, rounded-9, padding `1 6`) right-aligned.
   - **Active row**: bg `sidebar-active`, color `#fff`, font-weight 500, **2px left border** in `accent`, negative `margin-left: -2px` so the bar sits flush with the rail.
   - Nav order: Inbox · Dashboard · Calendar · Patients · Campaigns
4. **"Saved views" section** (overline 10.5px uppercase, letter-spacing 0.08em, opacity 0.4). Static items styled at opacity 0.55.
5. **User block** at bottom: 28px avatar + name (12.5 weight 500 white) + role (11px 0.45 white) + settings cog.

---

## Screens / Views

### 1 · Inbox (hero)
**Layout** — 4-column flex row, full-bleed: `Sidebar (220) | Thread list (340) | Conversation (1fr) | Patient panel (300)`. Min total width 1280, design target 1440×900.

**Thread list (340w)**
- Header (padding `16 18 12`, bottom border): "Inbox" title 17px weight 600 + filter/more icon buttons + search field (background `surface`, border, radius 7, padding `7 10`, includes `/` kbd hint).
- Filter chip strip: `All · 142 / Unread · 12 / Assigned to me · 28 / Unassigned · 4 / Escalated · 2`. Active chip uses `accent-soft` bg, `accent` fg.
- **Thread row** (padding `11 14`, bottom border):
  - 32px avatar
  - Name (13px, weight 600 if unread else 500), right-aligned mono timestamp
  - Channel chip + AI sparkle badge ("✨ AI" in `accent` 10px weight 600) + flag/attachment icons if applicable
  - Preview (12px, weight 500 + text color if unread, else weight 400 + text-dim), single-line ellipsis
  - Tag chips (10px, padding `1 6`, radius 3, bg `#F0EEE7`, border, color `text-dim`)
  - Assignment hint right-aligned (`⚠ Unassigned` or `→ Jordan K.`) in 10px text-faint
  - Active thread: white surface bg, **2px left border in accent**
  - Unread badge: top-right circle 18px, bg `accent`, count in mono

**Conversation pane (flex 1)**
- Header (padding `14 22`, bottom border): 36px avatar + name 15px weight 600 + patient meta chip ("Patient · 8 yrs") + line below with channel + phone + provider + online state. Right-aligned icon buttons (phone, calendar, star, more).
- Message stream (padding `20 22 12`, gap 14):
  - Date chips centered (11px, `surface-alt` bg, radius 10)
  - **System events**: centered inline pill — bolt icon + text + faint timestamp, `surface-alt` bg, 1px border
  - **Patient bubbles**: left-aligned, max 74%, bg `surface-alt`, 1px border, radius `14 14 14 4`
  - **Staff bubbles**: right-aligned, max 74%, bg `accent`, color white, radius `14 14 4 14`
  - Below each bubble: mono timestamp 10.5px in `text-faint`, with author for staff messages
- **AI suggestion strip** (above composer, margin `0 18 0`, padding `10 12`, radius 10, bg `accent-soft`):
  - Round 22px badge bg `accent` with sparkles icon
  - Overline "LUMEN SUGGESTS" 11px weight 600 uppercase letter-spacing 0.02em
  - Suggested reply body 13px line-height 1.5 with the suggested text in italics
  - Three buttons: **Use suggestion** (filled accent), **Edit** (white with border), **Dismiss** (text-only text-dim)
- **Composer** (padding `12 18 16`, top border):
  - Outer wrapper: 1px `border-strong`, radius 10, white bg
  - Top row: "REPLY VIA" overline + channel chips (active = `accent-soft` bg, `accent` fg) + right-aligned char counter `0 / 160` mono
  - Textarea: padding `6 12 8`, min-height 56, no border, "Write a reply, or press / for templates…"
  - Bottom row (top border 1px): icon buttons (paperclip, calendar, tag, sparkles) + right: "Save draft" text-only + **Send** primary button (bg `accent`, color white, radius 7, padding `7 14`, weight 600, with send icon)

**Patient panel (300w, right-bordered, scrollable)**
- Top block (padding `18 18 14`, center-aligned, bottom border): 56px avatar + name 15px weight 600 + demo line "F · 34 · Patient since 2017" + 3-up stat tiles ([Visits 14] [No-shows 0] [NPS 9]) each on white card.
- **Next appointment** card (white, 1px border, radius 8, padding 12): title + Thu indicator dot in `accent` + meta + amber warning row ("⚠ Patient asked to move this in current thread") in `#FBF6EC`.
- **Recent visits** rows (3 items, 1px between): visit type + provider + mono right-aligned date.
- **Tags** flex-wrap chips (11px, white bg, 1px border, text-dim) + "+ Add" outline chip.
- **Notes** card body text 12px text-dim line-height 1.55.

---

### 2 · Dashboard
**Layout** — `Sidebar | Main (flex 1, scrollable)`. Main contains a header bar then a content column at padding `24 32` with gap 18.

**Header bar** (padding `22 32 18`, bottom border):
- Left: overline "TUESDAY · MAY 22, 2026 · MAPLE FAMILY CLINIC" (11.5px mono) + h1 "Good morning, Jordan" (24px weight 600 letter-spacing -0.02em).
- Right: outline button "Start campaign" + filled accent "New patient" with `+` icon.

**KPI strip** — 4-up grid, gap 14. Each tile (1px border, radius 12, padding `16 18`):
- Overline label + tinted icon tile (26×26 radius 6, bg `accent-soft`, fg `accent`).
- Value 28px mono weight 600 + delta chip (`success` if good, `warn` otherwise).
- Subline 11.5px text-faint.
- The 4 KPIs are:
  1. Messages today — 47 / +18% / "12 awaiting reply"
  2. Median reply time — 4m 12s / −1m 04s / "team SLA 10m"
  3. Appointments — 28 / 31 / "90% booked" / "2 no-shows recovered"
  4. No-show risk — 4 / "3 outreach drafted" / "thu + fri appts"

**Below the KPIs** — two two-column rows, gap 18:

Row 1 (1.4fr / 1fr):
- **Inbox snapshot** card with header "What needs you in the next hour" + "Open inbox →" link. Rows: 28px avatar + name (with URGENT and ✨ DRAFTED badges where applicable) + preview + channel chip + mono timestamp.
- **Today · Dr. Lin** schedule card. Rows: mono time (38w) + name + type + status chip. Current slot highlighted with `accent-soft` row bg and 2px left accent border. Status colors: arrived (accent-soft), confirmed (neutral), no-show (`#FBE8E5` / danger), in-room (`#E6F2EA` / success), open (dashed border, faint text).

Row 2:
- **Messaging volume** — 14-day stacked bar chart, SMS (accent) + WhatsApp (`#5B8C5A`) + Email (`#7A5C9A`). Height 120, gap 6. Legend top-right.
- **Suggested follow-ups** — list with circular count badge (`accent-soft` bg, mono count) + tag name + label + outline CTA button per row. Header has sparkles icon and copy "Lumen sees these patients are due for outreach."

---

### 3 · Calendar
**Layout** — `Sidebar | Main (flex 1) | Right rail (280)`.

**Header** (padding `18 28 14`, white, bottom border):
- Overline "SCHEDULE" + h1 "Week of May 19, 2026"
- Prev / Today / Next buttons (30×30 outline)
- Day / Week / Month segmented switcher (`surface-alt` bg, padding 3, radius 7, inner button radius 5; active button is white with subtle shadow)
- Provider select on the right
- Filled "Book appointment" with `+` icon

**Week grid** — CSS Grid: `60px repeat(7, 1fr)`. Hour rows 56px tall, 8 AM → 5 PM.
- Day header row (sticky top): weekday overline (mono, uppercase) + 18px bold date + appt count (mono 10.5px). Today's column has `accent-soft` bg.
- Hour cells: 1px borders, today's column tinted `rgba(229,241,239,0.18)`.
- **Appointments** absolutely positioned inside the start cell:
  - top: `(hour - hourStart) * 56`, height: `dur * 56 - 2`
  - padding `4 7`, radius 4, **2px left border** in status color
  - First line: 10.5px weight 600 — optional `📹` for telehealth, patient initials/name, optional flag icon
  - Second line: 9.5px opacity 0.8 — appt type
  - Status palette: done (neutral), confirmed (accent-soft / teal border), arrived (filled accent white text), in-room (filled green white), no-show (danger soft), reschedule/tentative (warn, dashed border for tentative), block (striped `repeating-linear-gradient(135deg, …)`)
  - Current appointment: extra white-then-accent halo via double box-shadow
- **"Now" line** — 1.5px horizontal line in `danger` with a 8px dot at left and a "10:30 NOW" label (mono 9px white-bg) at right; positioned on today's column at the current hour.

**Right rail**
- "From messaging" header — "3 reschedule requests" h-style and "Patients asked in chat — accept to update slot"
- Per-request card: 28px avatar + name + AI auto-suggest badge if applicable; line: old time (strikethrough text-faint) → new time (text weight 600); "Accept & reply" (filled accent) and "Offer alts" (outline) buttons
- Waitlist (8) — patient lines with right-aligned "Text" button in accent
- This week stats — Booked 62/75, Open slots 13, No-show rate 1.6%, Reminders queued 47 (all mono right-aligned)

---

### 4 · Patient profile
**Layout** — `Sidebar | Main (flex 1, scrollable)`. Main is a single scroll surface.

1. **Breadcrumb bar** (white, 12 32 bottom border): clickable trail "Patients › Active · Maple › Maya Okafor" + right-aligned mono "MRN MO-4421".
2. **Profile header block** (padding 24 32, white, bottom border):
   - 72px avatar + name h1 (24px weight 600) + inline status pills (Active, VIP, SMS opt-in) — each `accent-soft` for active, neutral `#F0EEE7` for others
   - Below: 6 demo fields in a flex row gap 22 (DOB+age, pronouns, provider, since, phone, email) — faint label + value style
   - Right-aligned action group: **Message** (filled accent), **Book appt** (outline), more-icon
   - **Mini-KPI strip** below: 6-up gap 10, each `surface-alt` bg radius 8 padding `10 12`, overline + 17px mono value (success-colored for positive stats like 0 no-shows, $0 balance, etc.)
3. **Tab bar** (white, 0 32, 18px gap): Timeline, Messages (with count badge in `accent-soft`), Appointments, Labs, Billing, Notes, Files. Active tab gets 2px `accent` bottom border (offset −1).
4. **Body** — 2 columns `1fr / 320px`, padding 24 32, gap 20.

**Unified timeline** (left column):
- Filter chip strip top: All / Messages / Clinical / Billing (active = `accent-soft`)
- Container: white, 1px border, radius 12, padding `8 0`
- Each event row (padding `12 18`, gap 14):
  - Rail column 12w: 10px filled dot in type color, with a 2px vertical line down the entire rail
  - Right column:
    - Overline row: type label (10px uppercase weight 600 in type color) + optional badges (UNREAD in danger) + channel chip + author + right-aligned mono timestamp
    - Body 13px line-height 1.5. **Message events get a bubble container**: 8 12 padding, radius 7, `accent-soft` bg for staff, `surface-alt` bg for patient, 1px border matching
    - Optional `detail` line 11.5px text-dim
- Event type colors: message → accent, system → text-faint, appt → `#5B8C5A`, note → warn, lab → `#7A5C9A`, campaign → `#A85C8C`

**Right column** (320w stack of cards, gap 14, each card padding `14 16`, radius 10, 1px border, overline 11px text-dim 0.08em uppercase):
- **Care team** — avatar + name + role + right-aligned "Message" link per row
- **Insurance & billing** — key/value rows with verified status in success
- **Pinned notes** — Alert callout (`#FBF6EC` bg, `#F0E4C9` border, "⚠ ALERT" 10px warn label, then bold-ish body) + free-text note
- **Tags** — chip set + "+ Add" dashed outline chip

---

### 5 · Patient list & segments
**Layout** — `Sidebar | Segments rail (240) | Main (flex 1)`.

**Segments rail** (white, 1px right border):
- Header padding `20 18 12`: overline "Segments" + full-width dashed "New segment" button with `+`
- Item rows (`8 10` padding, radius 6):
  - Optional 7px colored dot indicating segment intent (success/danger/warn/etc.)
  - Name (12.5px, weight 600 when active)
  - Right-aligned count in mono (text-faint, text-accent when active)
  - Active = `accent-soft` row bg + 2px accent left border (offset −2)
- Segment seed list (counts): All patients 2841 / Active · last 90d 1842 *(active)* / New this month 47 / At no-show risk 23 / Dormant 6+ mo 412 / Birthday this week 18 / Annual physical due 142 / Outstanding balance 34 / Spanish-preferred 218 / Pediatric 386 / VIP 64

**Main header** (white, padding `20 32 14`):
- Overline "SEGMENT" + h1 "Active · last 90d" + sub "1,842 patients · updated 4m ago"
- Right buttons: Bulk tag (outline), Create campaign (outline), Message segment (filled accent)
- Below: search input (`surface-alt` bg, "Filter patients · try 'no-show > 1 AND last visit > 90d'") + active filter chips (`accent-soft`, dismissible with × glyph) + dashed "+ Add filter" chip

**Table** (white, full-width):
- Header row (`surface-alt` bg, 10.5px overline columns)
- Rows alternate `surface` / `surface-alt`, 1px border bottom, padding `10 14`
- Columns: checkbox, Patient (avatar + name + age/cohort), MRN (mono text-dim), Provider, Last contact (mono), Next appt, Status pill, Tags (max 2 visible chips), LTV (mono right-aligned $), NS (no-show count, colored: 0 faint, 1 warn, 2+ danger), action — "Msg" link in accent with chat icon
- Status pill palette: Active (accent-soft / success), New / New lead (accent-soft / accent), At risk (`#FBE8E5` / danger), Waitlist (`#FBF6EC` / warn), Dormant (neutral / text-faint)

**Footer** (white, 1px top border, padding `10 32`):
- Left "Showing 16 of 1,842 · 0 selected"
- Right pagination: outline arrows + "1 of 116" mono

---

### 6 · Campaigns
**Layout** — `Sidebar | Main (flex 1)`. Main has a header, then a split view: **Campaign list (380w)** + **Builder (flex 1, scrollable)**.

**Header** (padding `20 32 16`): overline + "Outreach" h1 + sub "4 running · 1 scheduled · 1 draft"; right buttons: "Suggest from inbox" (outline, sparkles icon in accent) + "New campaign" (filled).

**Campaign list** (white, right-bordered):
- Filter chip strip (padding `10 14`, 1px bottom border): All / Running / Scheduled / Drafts / Complete
- Rows (padding `14 16`, 1px bottom border):
  - Channel chip + name (13px, weight 500/600) + status pill on the right
  - Stats line in mono 11px text-dim: "{sent} sent · {replied} replied · {booked} booked" (booked in success when present)
  - Progress bar (h 4px, `surface-alt` bg) showing the campaign's primary conversion (booked/sent) in channel color
- Active campaign row: `surface-alt` bg + 2px accent left border (offset −2)
- Status pill palette: Running (accent-soft/accent), Scheduled (`#FBF6EC` / warn), Draft (neutral / text-dim), Complete (`#EDE9F2` / `#7A5C9A`)

**Builder** (`surface-alt` bg, padding `24 32`, max-width 760px column, gap 16):

Header card (white, 1px border, radius 12, padding 18):
- Campaign name h2 17px + ● Running pill + right-aligned "Started May 14 · 8 days running"
- 4-up KPI grid gap 10. Each: `surface-alt` bg radius 8 padding 12. Overline + 22px mono value (success when good, text-dim when neutral) + 11px text-faint subline.

Three numbered step blocks. Each (white card, radius 12, padding 18):
- Step badge: 22×22 rounded-6, `accent-soft` bg, `accent` mono weight 700 number
- Step title h3 14px + light gray subtitle + right-aligned "Edit" outline mini-button
- Content varies by step:

  **Step 1 · Audience** — flex-wrap pill list of filter chips (`accent-soft` bg) + "+ Add" dashed.

  **Step 2 · Sequence** — Vertical list, each touchpoint is a row of `Day label (70w mono)` + content card:
  - Card (`surface-alt` bg, 1px border, radius 8, padding 12): top row channel chip + title (12px weight 600) + right-aligned mono "{sent} sent · {replied} replied"
  - Body block: mono 12px, `surface` bg, padding 8, radius 5 — the message template text (with `{{first}}` token highlighting)
  - At the bottom: dashed outline "+ Add touchpoint" button aligned to the content column.

  **Step 3 · Goal & guardrails** — 2-column key/value grid with bottom borders on each row.

---

### 7 · Settings · Channels
**Layout** — `Sidebar | Settings sub-nav (220) | Main (flex 1)`.

**Settings sub-nav** (white, 1px right border):
- Header: overline "Settings" + "Maple Family Clinic" 15px weight 600
- Grouped nav. Groups: **Clinic** (General, Hours & holidays, Locations [2], Branding), **Messaging** (Channels *(active)*, Templates [24], AI assistant, Quiet hours, Auto-replies), **Workflow** (Team & roles [6], Routing rules, Tags, Custom fields), **Integrations** (EHR · Athena, Billing · Stripe, Calendar sync, API & webhooks), **Account** (Plan & billing, Audit log, Compliance · HIPAA)
- Group overline 10px uppercase text-faint; row padding `6 10`, active row gets `accent-soft` bg + 2px accent left border + weight 600

**Main header** (padding `20 32 16`, white, bottom border): overline "SETTINGS · MESSAGING" + "Channels" h1 + sub.

**Channel cards** (padding 32, max-width 960, gap 18). Each card (white, 1px border, radius 12):
- Header row (padding `16 20`): 40×40 channel icon tile (radius 9, `accent-soft` bg) + name 15px weight 600 + status pill (● dot + label, color = success/warn/text-faint) + mono number/handle below name + sub line in text-faint. Right-aligned **stat group** (3 stat columns: overline + 14px mono weight 600). Far right: "Manage" / "Connect" outline button.
- Optional body (1px top border, padding `8 20 14`) with `SettingRow` items: label (12.5 weight 500) + value (12 text-dim) + right-side "Edit" link or **iOS-style toggle** (32×18, bg accent when on, white knob 14×14 radius 50% with subtle shadow).

Channel seed data:
- SMS — connected, `+1 (415) 555-0100`, Twilio · A2P 10DLC · 200 msg/day soft cap. Stats: 1,284 / 74% / 4m 12s. Body rows: Display name, Default sender, MMS attachments, Two-way conversations (toggle on), Patient must confirm opt-in HIPAA (toggle on), Auto-link short URLs.
- WhatsApp — connected, `+1 (415) 555-0100`, 18 approved templates. Stats: 386 / 81% / 32% Spanish.
- Email — connected, `care@maplefamilyclinic.com`, Postmark DKIM/SPF · 99.4% deliverability. Stats: 512 / 64% / 22%.
- Voice — **warning**, voicemails → SMS, 1 prompt missing.
- In-app chat — off, lumen.app/p/maple, "Embed widget", 0 active sessions.

---

## Interactions & Behavior

### Global
- **`⌘N`** opens new message composer from anywhere
- **`/`** focuses search in any list
- **`⌘K`** opens command palette (Dense direction shows this in the bar)
- Sidebar collapse: not in current design but should snap to icon-only at <1100w
- All filter chips are dismissible (× glyph) and persist across page loads
- Hover state on cards: subtle background shift (`surface` → `surface-alt`) or `0 2px 6px rgba(0,0,0,0.05)` shadow
- Focus rings: `box-shadow: 0 0 0 2px {accent-soft}, 0 0 0 3px {accent}`

### Inbox
- Click a thread row → loads its conversation, marks unread→read
- Channel chips in composer switch the outgoing channel; character counter swaps for SMS-160 segments vs. email
- **AI suggestion strip** is the primary AI surface. Behavior:
  - When a draft is ready, the strip appears between message stream and composer
  - **Use suggestion** → fills the composer textarea (does **not** send); user can edit and Send
  - **Edit** → fills composer in a "review" state with the suggested text selected
  - **Dismiss** → removes the strip for this thread; logged as feedback
  - The strip should **never auto-send** — always require user confirmation
- Right panel "Patient asked to move this in current thread" tile is reactive — if the user accepts a reschedule, this warning clears
- AI badge ("✨ AI" / "✨ DRAFTED") on thread rows = there's a pending draft for that thread

### Scheduling
- **"From messaging" reschedule cards** on Calendar are derived from inbox AI inference. "Accept & reply" performs two actions atomically:
  1. Update the appointment slot
  2. Send a confirmation reply via the patient's preferred channel
- "Offer alts" opens a quick picker of 3 nearby openings and drafts a message offering them
- Time grid supports drag-resize (vertical only) to change duration; drag-move to change slot. Conflicts highlight in danger.
- Telehealth-flagged appointments display the `📹` glyph and silently provision a Zoom link on confirm
- Current-time line: position computed as `nowMinutesSinceStart / hourSpan * gridHeight`; auto-scrolls into view on initial load

### Patient profile
- Tab nav is client-side, no full reload; Timeline filter chips filter the same event stream
- Inline-editable: name, tags, pinned notes, contact fields. Click to edit, blur to save with a subtle "Saved" toast.
- Allergy alert is **always visible** regardless of which tab is active (it lives in the sidebar card column, not the tab body)
- "Message" actions throughout (header, care team, etc.) all route to the same Inbox composer, prefilled with the patient and last-used channel

### Patient list
- Segments are saved Boolean filter expressions; the search/filter bar supports a simple DSL (`field op value AND/OR ...`) — autocomplete on field names
- Multi-select via checkboxes; selecting any row reveals a bulk action bar at the bottom (tag, message segment, export, archive)
- Column headers are sortable (asc/desc with arrow indicator); LTV and NS columns default to numeric sort
- "Msg" link in row opens Inbox in a side-panel mode (does not navigate away)

### Campaigns
- Builder is **live** while running — KPI numbers refresh every 30s and stage stats update as touchpoints fire
- "Suggest from inbox" runs the AI over the current inbox + segment data and proposes a new campaign with audience filter + sequence pre-filled
- Auto-pause guardrail: if reply rate falls below threshold after N sends, status → "Paused — review" and a banner appears at the top of the builder

### Settings
- Toggle changes save optimistically with undo toast for 4s
- "Connect" on inactive channels launches a side-panel wizard (Twilio number purchase, WhatsApp template approval, etc.)

---

## State management

Suggested store shape (Redux/Zustand/whatever):

```
session: { user, clinic, role, permissions }
inbox: {
  threads: { byId, allIds, filters, activeView }
  conversations: { byThreadId: { messages, draft, aiSuggestion } }
  composer: { open, threadId, channel, body, attachments }
}
patients: {
  byId, allIds,
  segments: { byId, active, filters }
  profile: { tabsByPatientId }
}
schedule: {
  appointments: { byId, byDay }
  view: { mode: 'day'|'week'|'month', anchorDate, provider }
  rescheduleRequests: { fromInbox: [...] }   // bridge between inbox AI + calendar
}
campaigns: {
  byId, allIds, activeId,
  builder: { audience, sequence, guardrails, performance }
}
settings: {
  channels: { sms, whatsapp, email, voice, chat }
  templates, team, routing, integrations
}
ai: {
  suggestions: { byThreadId, byCampaignId }
  feedback: []
}
```

Critical cross-store flows:
- Inbox AI suggesting a reschedule writes to `schedule.rescheduleRequests.fromInbox` AND `inbox.conversations[id].aiSuggestion`
- Accepting a reschedule mutates `schedule.appointments` AND posts to `inbox.composer`
- Sending a campaign step mutates `inbox.threads` (one new thread per recipient if 2-way)

---

## Compliance notes

- **HIPAA**: every channel toggle must surface its compliance state. SMS body must never include PHI unless the patient has explicit opt-in (current toggle in Settings · SMS row "Patient must confirm opt-in").
- **Audit log**: every send/edit/reschedule action should be logged with actor, timestamp, before/after — surfaced under Settings · Account · Audit log (not designed in this pass; reuse a standard log table).
- **Quiet hours**: campaign engine must respect per-patient timezone; default 9 PM – 8 AM local.

---

## Assets

- **Fonts**: Google Fonts — Geist (300/400/500/600/700), Geist Mono (400/500). For Direction B: add DM Sans + Newsreader. For Direction C: IBM Plex Sans + Mono. Self-host in production.
- **Icons**: custom SVGs in `prototype/system.jsx` — re-author as React components or use a comparable open icon set (Lucide is closest in feel — 1.5–2px stroke, rounded caps). Replace the existing emoji icons.
- **Channel logos**: do not use vendor brand glyphs (WhatsApp/Apple/etc.); use the channel chips from this design.

---

## Files in this bundle

```
prototype/
├── index.html               · entry point, mounts the design canvas
├── design-canvas.jsx        · the canvas shell (Figma-ish presentation)
├── system.jsx               · Icons, Avatar, ChannelDot primitives
├── app.jsx                  · mounts all artboards
└── screens/
    ├── inbox-clinical.jsx   · Direction A · Inbox
    ├── inbox-warm.jsx       · Direction B · Inbox
    ├── inbox-dense.jsx      · Direction C · Inbox
    ├── dashboard.jsx        · Direction A
    ├── calendar.jsx         · Direction A
    ├── patient-profile.jsx  · Direction A
    ├── patient-list.jsx     · Direction A
    ├── campaigns.jsx        · Direction A
    └── settings.jsx         · Direction A
```

Open `prototype/index.html` in a browser to view the canvas. Use the artboard expand icon to focus any single screen fullscreen.

---

## Implementation order (suggested)

1. **Foundations** — install fonts; wire color/spacing/radius/type tokens into the existing theme; build/replace `Avatar`, `ChannelDot`, base `IconButton`, `Pill`/`Tag`, `Card`.
2. **Sidebar** — replace existing nav with the new structure (Inbox · Dashboard · Calendar · Patients · Campaigns). Drop the emoji KPI icons app-wide; switch to the new icon set.
3. **Inbox** — the hero. Get the 4-pane layout, thread row, message bubble, composer, and AI suggestion strip pixel-correct before anything else.
4. **Patient profile + timeline** — unifies messages with everything else; most of the data model lives here.
5. **Calendar** with the messaging-bridge "From messaging" rail — the moment that proves the messaging-first thesis.
6. **Patient list & segments** — DSL filter is the only non-trivial new mechanic.
7. **Campaigns builder** — depends on segments + inbox templates.
8. **Settings · Channels** — last; mostly forms wrapping existing integration code.

The dashboard is best built last — it composes data from all the other surfaces.
