// InboxDense.jsx — Direction C: Dense Pro
// Fully dark, Linear-like, dense data, keyboard-first, IBM Plex Sans/Mono.

const DenseTokens = {
  font: "'IBM Plex Sans', system-ui, sans-serif",
  mono: "'IBM Plex Mono', ui-monospace, monospace",
  bg: '#0B0D11',
  surface: '#12151B',
  surfaceAlt: '#171B23',
  surfaceHi: '#1D222B',
  border: '#22272F',
  borderStrong: '#2D333E',
  text: '#E8EAED',
  textDim: '#8B939F',
  textFaint: '#5C636E',
  sidebar: '#0B0D11',
  accent: '#7BB5F5',     // cool ice blue
  accentDim: '#4A6E8A',
  accentSoft: 'rgba(123,181,245,0.12)',
  success: '#5FB07B',
  warn: '#D9A445',
  danger: '#E16868',
  purple: '#A78BFA',
};

const DenseThreads = [
  { id: 'd1', n: 'Maya Okafor', mrn: 'MO-4421', t: '2m', c: 'sms', s: 'open', p: 'reschedule Thu 3pm video f/u → 5:30 same day OK?', tags: ['reschedule', 'p1'], unread: 2, ai: 'drafted', active: true },
  { id: 'd2', n: 'Daniel Reyes', mrn: 'DR-3018', t: '9m', c: 'whatsapp', s: 'open', p: 'confirm 12h fast pre blood draw — Wed 7am', tags: ['pre-visit'], unread: 1 },
  { id: 'd3', n: 'Aisha Patel', mrn: 'AP-5552', t: '14m', c: 'sms', s: 'open', p: 'insurance card uploaded — angle ok? 2 attachments', tags: ['intake'], unread: 0, attach: 2 },
  { id: 'd4', n: 'Greg Hollister', mrn: 'GH-1109', t: '22m', c: 'email', s: 'auto', p: 're: balance $182.40 — auto-reply sent', tags: ['billing'], unread: 0 },
  { id: 'd5', n: 'Sofia Bianchi', mrn: 'SB-2274', t: '38m', c: 'sms', s: 'open', p: 'better on new Rx. q on side effects — drowsiness AM', tags: ['follow-up'], unread: 0 },
  { id: 'd6', n: 'Marcus Lin', mrn: 'ML-9930', t: '1h', c: 'sms', s: 'urgent', p: 'NO-SHOW 10:00 today — draft outreach available', tags: ['no-show', 'p1'], unread: 1, ai: 'drafted', flag: true },
  { id: 'd7', n: 'Priya Ramaswamy', mrn: '—', t: '2h', c: 'voice', s: 'new', p: 'voicemail 0:43 — new patient, schedule', tags: ['new-patient'], unread: 0 },
  { id: 'd8', n: 'Owen Carter', mrn: 'OC-3367', t: '3h', c: 'sms', s: 'closed', p: 'confirmed Mon 14:15', tags: [], unread: 0 },
  { id: 'd9', n: 'Rebecca Wu', mrn: 'RW-7781', t: '4h', c: 'email', s: 'open', p: 'intake form done (4pp) → review', tags: ['forms'], unread: 0 },
  { id: 'd10', n: 'Sam Chen (guardian)', mrn: 'SC-0042', t: '5h', c: 'sms', s: 'open', p: 'asking what to bring for pediatric visit', tags: ['guardian'], unread: 0 },
  { id: 'd11', n: 'Hugo Pereira', mrn: 'HP-1188', t: '6h', c: 'whatsapp', s: 'open', p: 'rx refill request — metformin 500mg', tags: ['rx'], unread: 0 },
  { id: 'd12', n: 'Lin Family', mrn: '—', t: '8h', c: 'email', s: 'open', p: 'campaign reply — booked 2 flu shots Sat', tags: ['campaign'], unread: 0 },
];

function InboxDense() {
  const T = DenseTokens;
  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: T.bg, fontFamily: T.font, color: T.text,
      fontSize: 12.5, fontFeatureSettings: '"ss01", "cv11"',
    }}>
      {/* top app bar */}
      <div style={{
        height: 38, display: 'flex', alignItems: 'center',
        borderBottom: `1px solid ${T.border}`, padding: '0 12px', flexShrink: 0,
        background: T.surface,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, width: 220 }}>
          <div style={{
            width: 18, height: 18, borderRadius: 4, background: T.accent,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: T.bg, fontWeight: 700, fontSize: 11, fontFamily: T.mono,
          }}>L</div>
          <span style={{ fontWeight: 600, color: T.text, fontSize: 13 }}>lumen</span>
          <span style={{ color: T.textFaint, fontSize: 12 }}>/</span>
          <span style={{ color: T.textDim, fontSize: 12 }}>maple-clinic</span>
          <Icons.chevronDown size={11} stroke={T.textFaint}/>
        </div>

        <div style={{
          flex: 1, maxWidth: 520, margin: '0 auto', display: 'flex', alignItems: 'center', gap: 8,
          padding: '5px 12px', background: T.surfaceAlt, border: `1px solid ${T.border}`, borderRadius: 6,
        }}>
          <Icons.search size={12} stroke={T.textFaint}/>
          <input placeholder="Find anything — patients, messages, appts…" style={{
            border: 0, outline: 0, background: 'transparent', color: T.text,
            flex: 1, fontFamily: 'inherit', fontSize: 12.5,
          }}/>
          <kbd style={kbd(T)}>⌘K</kbd>
        </div>

        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6, width: 220, justifyContent: 'flex-end' }}>
          <span style={{ fontSize: 11, color: T.success, display: 'flex', alignItems: 'center', gap: 5, fontFamily: T.mono }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: T.success }}/>
            channels nominal
          </span>
          <button style={iconBtnD(T)}><Icons.bell size={13}/></button>
          <Avatar name="Jordan Kim" size={22} palette="C"/>
        </div>
      </div>

      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        {/* nav rail */}
        <nav style={{
          width: 180, background: T.bg, borderRight: `1px solid ${T.border}`,
          display: 'flex', flexDirection: 'column', padding: '10px 8px', flexShrink: 0,
        }}>
          {[
            { icon: Icons.inbox, label: 'Inbox', count: 12, active: true, kbd: 'I' },
            { icon: Icons.dashboard, label: 'Pulse', kbd: 'P' },
            { icon: Icons.calendar, label: 'Schedule', kbd: 'S' },
            { icon: Icons.users, label: 'Patients', count: 2841, kbd: 'C' },
            { icon: Icons.megaphone, label: 'Campaigns', count: 3, kbd: 'M' },
            { icon: Icons.settings, label: 'Settings', kbd: ',' },
          ].map((n, i) => {
            const Icn = n.icon;
            return (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 9, padding: '6px 9px',
                borderRadius: 5, cursor: 'pointer',
                background: n.active ? T.surfaceHi : 'transparent',
                color: n.active ? T.text : T.textDim,
                fontSize: 12.5, fontWeight: 400,
              }}>
                <Icn size={14} strokeWidth={1.5}/>
                <span style={{ flex: 1 }}>{n.label}</span>
                {n.count != null ? <span style={{ fontSize: 10.5, color: T.textFaint, fontFamily: T.mono }}>{n.count}</span> : null}
                <kbd style={{ ...kbd(T), opacity: n.active ? 1 : 0.4 }}>{n.kbd}</kbd>
              </div>
            );
          })}

          <div style={{ marginTop: 18, padding: '8px 9px 4px', fontSize: 10, color: T.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 600 }}>Filters</div>
          {[
            { label: 'Unassigned', n: 4, c: T.warn },
            { label: 'Escalated', n: 2, c: T.danger },
            { label: 'No-show', n: 3, c: T.danger },
            { label: 'Awaiting fast', n: 6, c: T.purple },
            { label: 'New patient', n: 5, c: T.accent },
            { label: 'AI drafted', n: 14, c: T.success },
          ].map((f, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 8, padding: '4px 9px',
              fontSize: 12, color: T.textDim, cursor: 'pointer',
            }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: f.c }}/>
              <span style={{ flex: 1 }}>{f.label}</span>
              <span style={{ fontFamily: T.mono, fontSize: 10.5, color: T.textFaint }}>{f.n}</span>
            </div>
          ))}

          <div style={{ marginTop: 18, padding: '8px 9px 4px', fontSize: 10, color: T.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 600 }}>Channels</div>
          {[['SMS', 89, 'sms'], ['WhatsApp', 31, 'whatsapp'], ['Email', 14, 'email'], ['Voice', 8, 'voice']].map(([l, n, c], i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 8, padding: '4px 9px',
              fontSize: 12, color: T.textDim, cursor: 'pointer',
            }}>
              <ChannelDot channel={c} size={10}/>
              <span style={{ flex: 1 }}>{l}</span>
              <span style={{ fontFamily: T.mono, fontSize: 10.5, color: T.textFaint }}>{n}</span>
            </div>
          ))}
        </nav>

        {/* Thread list — dense table */}
        <div style={{
          width: 420, borderRight: `1px solid ${T.border}`,
          display: 'flex', flexDirection: 'column', flexShrink: 0, background: T.surface,
        }}>
          <div style={{
            padding: '8px 12px', borderBottom: `1px solid ${T.border}`,
            display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: T.text }}>Inbox</span>
            <span style={{ fontSize: 11, color: T.textFaint, fontFamily: T.mono }}>142 open · 12 unread</span>
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
              <button style={iconBtnD(T)}><Icons.filter size={12}/></button>
              <button style={iconBtnD(T)}><Icons.sparkles size={12}/></button>
              <button style={iconBtnD(T)}><Icons.more size={12}/></button>
            </div>
          </div>
          <div style={{
            padding: '6px 12px', borderBottom: `1px solid ${T.border}`,
            display: 'flex', gap: 4, fontSize: 11, color: T.textDim,
          }}>
            {[
              ['all', 142, true],
              ['unread', 12],
              ['mine', 28],
              ['unassigned', 4],
              ['flagged', 2],
            ].map(([l, n, a], i) => (
              <span key={i} style={{
                padding: '2px 7px', borderRadius: 4, cursor: 'pointer',
                background: a ? T.surfaceHi : 'transparent',
                color: a ? T.text : T.textDim,
                fontFamily: T.mono,
              }}>{l} <span style={{ color: T.textFaint }}>{n}</span></span>
            ))}
          </div>
          <div style={{ flex: 1, overflow: 'auto' }}>
            {DenseThreads.map((t, i) => <DenseThreadRow key={t.id} t={t} i={i}/>)}
          </div>
        </div>

        {/* Conversation */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          <div style={{
            padding: '8px 16px', borderBottom: `1px solid ${T.border}`,
            display: 'flex', alignItems: 'center', gap: 10, background: T.surface,
            height: 44, flexShrink: 0,
          }}>
            <Avatar name="Maya Okafor" size={26} palette="C"/>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontWeight: 600, color: T.text }}>Maya Okafor</span>
              <span style={{ fontFamily: T.mono, fontSize: 11, color: T.textFaint }}>MO-4421</span>
              <span style={{ padding: '1px 6px', fontSize: 10, color: T.danger, background: 'rgba(225,104,104,0.12)', borderRadius: 3, fontFamily: T.mono, letterSpacing: '0.05em' }}>P1</span>
              <span style={{ padding: '1px 6px', fontSize: 10, color: T.success, background: T.accentSoft, borderRadius: 3, fontFamily: T.mono }}>● online</span>
            </div>
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 4, alignItems: 'center' }}>
              <span style={{ fontSize: 10.5, color: T.textFaint, marginRight: 6, fontFamily: T.mono }}>thread #t-4129</span>
              {[Icons.phone, Icons.calendar, Icons.tag, Icons.archive, Icons.more].map((Icn, i) => (
                <button key={i} style={iconBtnD(T)}><Icn size={12}/></button>
              ))}
            </div>
          </div>

          {/* timeline-style messages */}
          <div style={{ flex: 1, overflow: 'auto', padding: '12px 18px', display: 'flex', flexDirection: 'column', gap: 2 }}>
            <DenseEvent T={T} type="msg" who="patient" name="Maya" time="Yesterday 16:42" text="lab results came in via portal — cholesterol bumped up vs last year, should we chat?"/>
            <DenseEvent T={T} type="system" time="Yesterday 18:10" text="Dr. Lin reviewed labs — note added: Mild LDL increase, dietary follow-up 3mo"/>
            <DenseEvent T={T} type="msg" who="staff" name="Jordan Kim" time="Yesterday 18:48" text="Hi Maya — totally normal to check in. Dr. Lin saw labs, mild increase, not urgent. We can do a 15min video f/u next week or wait til your next physical. What works?"/>
            <DenseEvent T={T} type="msg" who="patient" name="Maya" time="Yesterday 19:01" text="video f/u works — thursday afternoon?"/>
            <DenseEvent T={T} type="system" time="Yesterday 19:04" text="Appointment booked: Thu May 28 15:00 · Dr. Lin · video · 15min · #apt-9201"/>
            <DenseEvent T={T} type="msg" who="staff" name="Jordan Kim" time="Yesterday 19:04" text="Booked Thu May 28 3:00 PM with Dr. Lin (video). Zoom 30min before. Anything else?"/>
            <DenseEvent T={T} type="msg" who="patient" name="Maya" time="Today 09:12" text="hi! can I move my Thursday 3pm? work thing. could do 5:30 same day?" unread/>
            <DenseEvent T={T} type="ai" time="Today 09:13" text="Lumen drafted reply · suggested swap to 17:30 (Dr. Lin available) · ready to send"/>
          </div>

          {/* composer */}
          <div style={{
            borderTop: `1px solid ${T.border}`, background: T.surface, padding: 8, flexShrink: 0,
          }}>
            <div style={{
              border: `1px solid ${T.borderStrong}`, borderRadius: 6, background: T.surfaceAlt,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', padding: '6px 10px', borderBottom: `1px solid ${T.border}`, gap: 6 }}>
                <span style={{ fontSize: 10.5, color: T.textFaint, fontFamily: T.mono, letterSpacing: '0.05em' }}>REPLY VIA</span>
                {['sms', 'whatsapp', 'email'].map((c, i) => (
                  <button key={i} style={{
                    fontSize: 11, padding: '2px 8px', borderRadius: 3,
                    background: i === 0 ? T.accentSoft : 'transparent',
                    color: i === 0 ? T.accent : T.textDim,
                    border: 'none', cursor: 'pointer', fontFamily: T.mono,
                  }}>{c}</button>
                ))}
                <span style={{ marginLeft: 'auto', fontSize: 10.5, color: T.textFaint, fontFamily: T.mono }}>↵ to send · ⇧↵ newline</span>
              </div>
              <div style={{
                padding: '10px 12px', fontFamily: T.font, fontSize: 13, color: T.text, minHeight: 70,
                lineHeight: 1.55,
              }}>
                <span style={{ background: T.accentSoft, padding: '0 4px', borderRadius: 2, color: T.accent }}>
                  Sure — I just moved you to Thu May 28 at 5:30 PM with Dr. Lin. New Zoom link will arrive 30 min before. Let me know if anything else!
                </span>
                <span style={{ display: 'inline-block', width: 8, height: 14, background: T.accent, verticalAlign: 'middle', marginLeft: 2 }}/>
              </div>
              <div style={{ display: 'flex', padding: '6px 8px', borderTop: `1px solid ${T.border}`, alignItems: 'center', gap: 6 }}>
                <button style={{ ...chipD(T), color: T.success }}>↵ Accept draft</button>
                <button style={chipD(T)}>↹ Tab to edit</button>
                <button style={chipD(T)}>⌘P templates</button>
                <span style={{ marginLeft: 'auto', fontSize: 11, color: T.textFaint, fontFamily: T.mono }}>164 chars · 1 SMS</span>
                <button style={{
                  padding: '4px 12px', background: T.accent, color: T.bg, border: 'none', borderRadius: 4,
                  fontFamily: 'inherit', fontSize: 12, fontWeight: 600, cursor: 'pointer',
                  display: 'inline-flex', alignItems: 'center', gap: 4,
                }}>Send <Icons.send size={11}/></button>
              </div>
            </div>
          </div>
        </div>

        {/* Right context — minimal, info-dense */}
        <aside style={{
          width: 280, background: T.surface, borderLeft: `1px solid ${T.border}`,
          display: 'flex', flexDirection: 'column', flexShrink: 0, overflow: 'auto',
        }}>
          <div style={{ padding: '14px 16px', borderBottom: `1px solid ${T.border}` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Avatar name="Maya Okafor" size={36} palette="C"/>
              <div>
                <div style={{ fontWeight: 600, color: T.text, fontSize: 13 }}>Maya Okafor</div>
                <div style={{ fontSize: 11, color: T.textFaint, fontFamily: T.mono }}>MO-4421 · F · 34 · since 2017-03</div>
              </div>
            </div>
          </div>

          <DenseRow T={T} k="next appt" v="thu may 28 · 15:00 → 17:30?" vc={T.warn}/>
          <DenseRow T={T} k="provider" v="dr. lin (J. Lin, MD)"/>
          <DenseRow T={T} k="last visit" v="may 14 · 6mo checkup"/>
          <DenseRow T={T} k="lifetime visits" v="14" mono/>
          <DenseRow T={T} k="no-shows (12mo)" v="0" mono/>
          <DenseRow T={T} k="ltv" v="$3,820" mono/>
          <DenseRow T={T} k="nps" v="9 (promoter)" vc={T.success}/>
          <DenseRow T={T} k="insurance" v="PPO BlueShield #4421"/>
          <DenseRow T={T} k="balance" v="$0.00" mono vc={T.success}/>
          <DenseRow T={T} k="risk flags" v="—" vc={T.textFaint}/>
          <DenseRow T={T} k="campaign" v="annual labs (apr 2026)"/>
          <DenseRow T={T} k="prefs" v="sms · 24h+1h reminders"/>

          <div style={{ padding: '14px 16px', borderTop: `1px solid ${T.border}` }}>
            <div style={{ fontSize: 10, color: T.textFaint, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>Recent threads</div>
            {['Reschedule Apr 03', 'Lab results question Apr 18', 'Flu shot reminder Oct \'24'].map((t, i) => (
              <div key={i} style={{ fontSize: 11.5, color: T.textDim, padding: '4px 0', borderBottom: i < 2 ? `1px solid ${T.border}` : 'none', fontFamily: T.mono }}>
                #{1284 - i} · {t}
              </div>
            ))}
          </div>
        </aside>
      </div>

      {/* status bar */}
      <div style={{
        height: 22, borderTop: `1px solid ${T.border}`, background: T.surface,
        display: 'flex', alignItems: 'center', padding: '0 12px', gap: 12,
        fontSize: 10.5, color: T.textFaint, fontFamily: T.mono, flexShrink: 0,
      }}>
        <span>● connected</span>
        <span>queue: 0</span>
        <span>last sync: 12s</span>
        <span style={{ marginLeft: 'auto' }}>j/k navigate · r reply · e archive · ⌘k command</span>
      </div>
    </div>
  );
}

function DenseThreadRow({ t, i }) {
  const T = DenseTokens;
  return (
    <div style={{
      display: 'flex', gap: 9, padding: '8px 12px',
      borderBottom: `1px solid ${T.border}`,
      background: t.active ? T.surfaceHi : (i % 2 ? T.surface : T.surface),
      borderLeft: t.active ? `2px solid ${T.accent}` : '2px solid transparent',
      cursor: 'pointer', position: 'relative',
    }}>
      <div style={{ width: 14, paddingTop: 2 }}>
        {t.unread ? <span style={{ display: 'block', width: 6, height: 6, borderRadius: '50%', background: T.accent }}/> : null}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
          <span style={{ fontWeight: t.unread ? 600 : 500, fontSize: 12.5, color: t.unread ? T.text : T.textDim }}>{t.n}</span>
          <span style={{ fontSize: 10.5, color: T.textFaint, fontFamily: T.mono }}>{t.mrn}</span>
          <ChannelDot channel={t.c} size={10}/>
          {t.flag ? <Icons.flag size={10} stroke={T.danger}/> : null}
          <span style={{ marginLeft: 'auto', fontSize: 10.5, color: T.textFaint, fontFamily: T.mono }}>{t.t}</span>
        </div>
        <div style={{
          fontSize: 12, color: t.unread ? T.text : T.textDim, marginTop: 3,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', lineHeight: 1.4,
        }}>{t.p}</div>
        <div style={{ display: 'flex', gap: 4, marginTop: 4, alignItems: 'center' }}>
          {t.tags.map((tg, j) => (
            <span key={j} style={{
              fontSize: 10, padding: '0 5px', borderRadius: 2,
              background: tg === 'p1' ? 'rgba(225,104,104,0.12)' : T.surfaceHi,
              color: tg === 'p1' ? T.danger : T.textDim,
              fontFamily: T.mono, fontWeight: 500,
            }}>{tg}</span>
          ))}
          {t.ai ? <span style={{ fontSize: 10, color: T.success, fontFamily: T.mono, marginLeft: 'auto' }}>ai/{t.ai}</span> : null}
          {t.attach ? <span style={{ fontSize: 10, color: T.textFaint, fontFamily: T.mono, marginLeft: t.ai ? 0 : 'auto' }}>📎{t.attach}</span> : null}
        </div>
      </div>
    </div>
  );
}

function DenseEvent({ T, type, who, name, time, text, unread }) {
  if (type === 'system') {
    return (
      <div style={{
        display: 'flex', gap: 12, padding: '4px 0',
        fontSize: 11.5, color: T.textFaint, fontFamily: T.mono,
      }}>
        <span style={{ width: 100, flexShrink: 0 }}>{time}</span>
        <span style={{ color: T.textFaint }}>→ {text}</span>
      </div>
    );
  }
  if (type === 'ai') {
    return (
      <div style={{
        display: 'flex', gap: 12, padding: '4px 0',
        fontSize: 11.5, color: T.accent, fontFamily: T.mono,
      }}>
        <span style={{ width: 100, flexShrink: 0, color: T.textFaint }}>{time}</span>
        <span>✨ {text}</span>
      </div>
    );
  }
  const fromPatient = who === 'patient';
  return (
    <div style={{
      display: 'flex', gap: 12, padding: '8px 0',
      borderLeft: unread ? `2px solid ${T.accent}` : '2px solid transparent',
      paddingLeft: 8, marginLeft: -10,
    }}>
      <div style={{ width: 100, flexShrink: 0, fontSize: 11, color: T.textFaint, fontFamily: T.mono, paddingTop: 1 }}>
        {time}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 4 }}>
          <span style={{
            fontWeight: 600, fontSize: 12, color: fromPatient ? T.accent : T.purple,
          }}>{name}</span>
          <span style={{
            fontSize: 9.5, padding: '0 5px', borderRadius: 2,
            background: T.surfaceHi, color: T.textFaint, fontFamily: T.mono,
          }}>{fromPatient ? 'patient · sms' : 'staff · sms'}</span>
        </div>
        <div style={{ fontSize: 13, lineHeight: 1.55, color: T.text }}>{text}</div>
      </div>
    </div>
  );
}

function DenseRow({ T, k, v, vc, mono }) {
  return (
    <div style={{
      display: 'flex', padding: '5px 16px', alignItems: 'baseline',
      borderBottom: `1px solid ${T.border}`,
    }}>
      <span style={{ fontSize: 10.5, color: T.textFaint, fontFamily: T.mono, width: 100, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{k}</span>
      <span style={{
        fontSize: 12, color: vc || T.text, fontFamily: mono ? T.mono : 'inherit', flex: 1,
        textAlign: 'right',
      }}>{v}</span>
    </div>
  );
}

function iconBtnD(T) {
  return {
    width: 24, height: 24, borderRadius: 4, border: 'none',
    background: 'transparent', color: T.textDim,
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    cursor: 'pointer', fontFamily: 'inherit',
  };
}
function chipD(T) {
  return {
    fontSize: 11, padding: '3px 7px', borderRadius: 3,
    background: T.surfaceHi, color: T.textDim, border: `1px solid ${T.border}`,
    fontFamily: T.mono, cursor: 'pointer',
  };
}
function kbd(T) {
  return {
    fontSize: 9.5, padding: '1px 5px', borderRadius: 3,
    background: T.bg, color: T.textFaint, border: `1px solid ${T.border}`,
    fontFamily: T.mono, lineHeight: 1.2,
  };
}

window.InboxDense = InboxDense;
window.DenseTokens = DenseTokens;
