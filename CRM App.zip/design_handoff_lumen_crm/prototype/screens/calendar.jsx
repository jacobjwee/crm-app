// Calendar.jsx — Week schedule with messaging-integrated slots

function Calendar() {
  const T = ClinicalTokens;
  const days = ['Mon 19', 'Tue 20', 'Wed 21', 'Thu 22', 'Fri 23', 'Sat 24', 'Sun 25'];
  const hours = ['8 AM', '9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM', '4 PM', '5 PM'];
  // appts laid out as: { day(0-6), startHour(8-17), dur(hours), title, patient, type, status }
  const appts = [
    { d: 0, h: 8.5, dur: 0.5, p: 'D. Reyes', t: 'Blood draw', status: 'done' },
    { d: 0, h: 9, dur: 0.5, p: 'L. Ortiz', t: 'Follow-up', status: 'done' },
    { d: 0, h: 10.5, dur: 1, p: 'N. Carter', t: 'Annual physical', status: 'done' },
    { d: 0, h: 14, dur: 0.5, p: 'J. Park', t: 'Telehealth', status: 'done', telehealth: true },
    { d: 0, h: 15.5, dur: 0.5, p: 'A. Singh', t: 'Vaccination', status: 'done' },

    { d: 1, h: 8.5, dur: 0.5, p: 'D. Reyes', t: 'Blood draw', status: 'arrived' },
    { d: 1, h: 9, dur: 0.5, p: 'A. Patel', t: 'New patient', status: 'confirmed' },
    { d: 1, h: 9.5, dur: 0.5, p: 'S. Bianchi', t: 'Follow-up', status: 'confirmed' },
    { d: 1, h: 10, dur: 0.5, p: 'M. Lin', t: 'Annual', status: 'no-show' },
    { d: 1, h: 10.5, dur: 0.5, p: 'O. Carter', t: 'Vaccine', status: 'in-room', current: true },
    { d: 1, h: 11.5, dur: 0.5, p: 'S. Chen', t: 'Peds sick', status: 'confirmed' },
    { d: 1, h: 14, dur: 1, p: 'H. Pereira', t: 'Rx review', status: 'confirmed', telehealth: true },
    { d: 1, h: 15.5, dur: 0.5, p: 'R. Wu', t: 'Intake review', status: 'confirmed' },

    { d: 2, h: 9, dur: 1, p: 'T. Okafor', t: 'Annual physical', status: 'confirmed' },
    { d: 2, h: 11, dur: 0.5, p: 'C. Mendes', t: 'Follow-up', status: 'confirmed' },
    { d: 2, h: 14, dur: 0.5, p: 'I. Park', t: 'Lab review', status: 'confirmed' },

    { d: 3, h: 9, dur: 0.5, p: 'B. Liang', t: 'Vaccination', status: 'confirmed' },
    { d: 3, h: 10.5, dur: 0.5, p: 'E. Davis', t: 'New patient', status: 'confirmed', flag: true },
    { d: 3, h: 15, dur: 0.5, p: 'M. Okafor', t: 'Video f/u', status: 'reschedule', telehealth: true, flag: true },
    { d: 3, h: 17.5, dur: 0.5, p: 'M. Okafor', t: 'Video f/u (moved)', status: 'tentative', telehealth: true },

    { d: 4, h: 9, dur: 0.5, p: 'P. Ramaswamy', t: 'New patient', status: 'confirmed' },
    { d: 4, h: 10, dur: 1, p: 'Flu shot pop-up', t: 'Walk-in block', status: 'block' },
    { d: 4, h: 14, dur: 0.5, p: 'K. Roy', t: 'Follow-up', status: 'confirmed' },

    { d: 5, h: 9, dur: 4, p: 'Saturday flu clinic', t: '12 booked / 30 slots', status: 'block', big: true },
  ];

  const statusMap = {
    done: { bg: '#EEEAE0', fg: T.textDim, border: '#DCD5C6' },
    confirmed: { bg: '#E5F1EF', fg: '#1E6A60', border: T.accent },
    arrived: { bg: T.accent, fg: '#fff', border: T.accent },
    'in-room': { bg: '#3E8C5A', fg: '#fff', border: '#3E8C5A' },
    'no-show': { bg: '#FBE8E5', fg: T.danger, border: T.danger },
    reschedule: { bg: '#FBF6EC', fg: T.warn, border: T.warn },
    tentative: { bg: '#FBF6EC', fg: T.warn, border: T.warn, dashed: true },
    block: { bg: '#F0EEE7', fg: T.textDim, border: T.border, stripe: true },
  };

  const colW = `1fr`;
  const hourH = 56;

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex',
      background: T.bg, fontFamily: T.font, color: T.text, fontSize: 13,
    }}>
      <ClinicalSidebar2 active="Calendar"/>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {/* header */}
        <div style={{
          padding: '18px 28px 14px', borderBottom: `1px solid ${T.border}`,
          background: T.surface, display: 'flex', alignItems: 'center', gap: 14,
        }}>
          <div>
            <div style={{ fontSize: 11.5, color: T.textDim, fontFamily: T.mono, marginBottom: 4 }}>SCHEDULE</div>
            <h1 style={{ margin: 0, fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em' }}>Week of May 19, 2026</h1>
          </div>
          <div style={{ display: 'flex', gap: 4, marginLeft: 16 }}>
            <button style={iconBtnL(T)}><Icons.chevronLeft size={14}/></button>
            <button style={{ ...iconBtnL(T), padding: '0 12px', width: 'auto' }}>Today</button>
            <button style={iconBtnL(T)}><Icons.chevronRight size={14}/></button>
          </div>
          <div style={{ display: 'flex', gap: 2, marginLeft: 8, background: T.surfaceAlt, padding: 3, borderRadius: 7 }}>
            {['Day', 'Week', 'Month'].map((v, i) => (
              <button key={i} style={{
                padding: '4px 12px', borderRadius: 5, fontSize: 12, border: 'none',
                background: i === 1 ? T.surface : 'transparent',
                color: i === 1 ? T.text : T.textDim, cursor: 'pointer',
                fontFamily: 'inherit', fontWeight: i === 1 ? 600 : 500,
                boxShadow: i === 1 ? '0 1px 2px rgba(0,0,0,0.04)' : 'none',
              }}>{v}</button>
            ))}
          </div>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
            <select style={{
              fontFamily: 'inherit', fontSize: 12, padding: '7px 10px', borderRadius: 7,
              border: `1px solid ${T.border}`, background: T.surface, color: T.text,
            }}>
              <option>Dr. Lin · Mon–Fri</option>
            </select>
            <button style={{
              padding: '7px 14px', borderRadius: 7, background: T.accent, color: '#fff',
              border: 'none', fontFamily: 'inherit', fontSize: 12.5, fontWeight: 600, cursor: 'pointer',
              display: 'inline-flex', alignItems: 'center', gap: 6,
            }}><Icons.plus size={13} strokeWidth={2}/> Book appointment</button>
          </div>
        </div>

        {/* grid */}
        <div style={{ flex: 1, overflow: 'auto', background: T.surface }}>
          <div style={{ display: 'grid', gridTemplateColumns: `60px repeat(7, ${colW})`, minWidth: '100%' }}>
            {/* day header row */}
            <div style={{ borderBottom: `1px solid ${T.border}`, borderRight: `1px solid ${T.border}` }}/>
            {days.map((d, i) => (
              <div key={i} style={{
                padding: '12px 14px', borderBottom: `1px solid ${T.border}`,
                borderRight: i < 6 ? `1px solid ${T.border}` : 'none',
                background: i === 1 ? T.accentSoft : 'transparent',
                position: 'sticky', top: 0, zIndex: 1,
              }}>
                <div style={{ fontSize: 11, color: T.textDim, fontFamily: T.mono, marginBottom: 2 }}>{d.split(' ')[0].toUpperCase()}</div>
                <div style={{ fontSize: 18, fontWeight: 600, color: i === 1 ? T.accent : T.text, letterSpacing: '-0.01em' }}>{d.split(' ')[1]}</div>
                <div style={{ fontSize: 10.5, color: T.textFaint, marginTop: 2, fontFamily: T.mono }}>
                  {[8, 14, 12, 13, 9, 16, 0][i]} appts
                </div>
              </div>
            ))}

            {/* hour rows */}
            {hours.map((h, hi) => (
              <React.Fragment key={hi}>
                <div style={{
                  borderBottom: `1px solid ${T.border}`, borderRight: `1px solid ${T.border}`,
                  padding: '4px 8px', fontSize: 10, color: T.textFaint, fontFamily: T.mono,
                  height: hourH,
                }}>{h}</div>
                {days.map((_, di) => {
                  const cellAppts = appts.filter(a => a.d === di && a.h >= 8 + hi && a.h < 8 + hi + 1);
                  return (
                    <div key={di} style={{
                      borderBottom: `1px solid ${T.border}`,
                      borderRight: di < 6 ? `1px solid ${T.border}` : 'none',
                      height: hourH, position: 'relative',
                      background: di === 1 ? 'rgba(229,241,239,0.18)' : 'transparent',
                    }}>
                      {cellAppts.map((a, ai) => {
                        const sc = statusMap[a.status];
                        const offset = (a.h - (8 + hi)) * hourH;
                        const height = a.dur * hourH - 2;
                        return (
                          <div key={ai} style={{
                            position: 'absolute', top: offset + 1, left: 3, right: 3,
                            height,
                            padding: '4px 7px',
                            background: sc.bg, color: sc.fg, borderRadius: 4,
                            borderLeft: `2px solid ${sc.border}`,
                            border: sc.dashed ? `1px dashed ${sc.border}` : undefined,
                            fontSize: 10.5, lineHeight: 1.25, overflow: 'hidden',
                            boxShadow: a.current ? '0 0 0 2px #fff, 0 0 0 4px ' + T.accent : 'none',
                            backgroundImage: sc.stripe ? 'repeating-linear-gradient(135deg, transparent, transparent 4px, rgba(0,0,0,0.04) 4px, rgba(0,0,0,0.04) 8px)' : undefined,
                          }}>
                            <div style={{ fontWeight: 600, fontSize: a.big ? 11.5 : 10.5, display: 'flex', alignItems: 'center', gap: 4, marginBottom: 1 }}>
                              {a.telehealth ? <span style={{ fontSize: 8 }}>📹</span> : null}
                              {a.p}
                              {a.flag ? <Icons.flag size={9} stroke={sc.fg}/> : null}
                            </div>
                            <div style={{ fontSize: 9.5, opacity: 0.8 }}>{a.t}</div>
                          </div>
                        );
                      })}
                      {/* now line on Tue at 10:30 */}
                      {di === 1 && hi === 2 ? (
                        <div style={{
                          position: 'absolute', top: hourH * 0.5, left: 0, right: 0,
                          borderTop: `1.5px solid ${T.danger}`, zIndex: 2,
                        }}>
                          <span style={{
                            position: 'absolute', left: -5, top: -4, width: 8, height: 8,
                            borderRadius: '50%', background: T.danger,
                          }}/>
                          <span style={{
                            position: 'absolute', right: 4, top: -8, fontSize: 9, color: T.danger,
                            background: '#fff', padding: '0 4px', fontFamily: T.mono, fontWeight: 600,
                          }}>10:30 NOW</span>
                        </div>
                      ) : null}
                    </div>
                  );
                })}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      {/* Right rail: pending requests + waitlist */}
      <aside style={{
        width: 280, background: T.surfaceAlt, borderLeft: `1px solid ${T.border}`,
        display: 'flex', flexDirection: 'column', flexShrink: 0, overflow: 'auto',
      }}>
        <div style={{ padding: '20px 18px 14px', borderBottom: `1px solid ${T.border}` }}>
          <div style={{ fontSize: 11, color: T.textDim, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 4 }}>
            From messaging
          </div>
          <div style={{ fontSize: 14, fontWeight: 600, color: T.text }}>3 reschedule requests</div>
          <div style={{ fontSize: 11.5, color: T.textDim, marginTop: 2 }}>Patients asked in chat — accept to update slot</div>
        </div>

        {[
          { name: 'Maya Okafor', from: 'Thu 3:00 PM', to: 'Thu 5:30 PM', ai: true },
          { name: 'Greg Hollister', from: 'Fri 11:00 AM', to: 'Mon 9:00 AM', ai: false },
          { name: 'Carla Mendes', from: 'Wed 11:00 AM', to: 'Wed 4:00 PM', ai: true },
        ].map((r, i) => (
          <div key={i} style={{ padding: '12px 18px', borderBottom: `1px solid ${T.border}` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 8 }}>
              <Avatar name={r.name} size={28} palette="A"/>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12.5, fontWeight: 500 }}>{r.name}</div>
                {r.ai ? <div style={{ fontSize: 10, color: T.accent, fontWeight: 600 }}>✨ Lumen auto-suggest</div> : null}
              </div>
            </div>
            <div style={{ fontSize: 11.5, color: T.textDim, lineHeight: 1.55 }}>
              <span style={{ textDecoration: 'line-through', color: T.textFaint }}>{r.from}</span>
              {' → '}
              <span style={{ color: T.text, fontWeight: 600 }}>{r.to}</span>
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
              <button style={{
                fontSize: 11, padding: '4px 10px', borderRadius: 5, background: T.accent, color: '#fff', border: 'none',
                fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit',
              }}>Accept &amp; reply</button>
              <button style={{
                fontSize: 11, padding: '4px 10px', borderRadius: 5, background: T.surface, color: T.text,
                border: `1px solid ${T.border}`, cursor: 'pointer', fontFamily: 'inherit',
              }}>Offer alts</button>
            </div>
          </div>
        ))}

        <div style={{ padding: '14px 18px 10px', borderBottom: `1px solid ${T.border}` }}>
          <div style={{ fontSize: 11, color: T.textDim, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>Waitlist (8)</div>
          {[
            'Hannah Wright · earlier appt',
            'Tomás Okafor · Fri AM',
            'Lara Petrov · cancel pickup',
          ].map((s, i) => (
            <div key={i} style={{
              fontSize: 12, color: T.text, padding: '6px 0',
              borderBottom: i < 2 ? `1px solid ${T.border}` : 'none',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <span>{s}</span>
              <button style={{ fontSize: 10.5, color: T.accent, background: 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontWeight: 600 }}>Text</button>
            </div>
          ))}
        </div>

        <div style={{ padding: '14px 18px' }}>
          <div style={{ fontSize: 11, color: T.textDim, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>This week</div>
          <div style={{ fontSize: 12, color: T.textDim, lineHeight: 2 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Booked</span><span style={{ fontFamily: T.mono, color: T.text }}>62 / 75</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Open slots</span><span style={{ fontFamily: T.mono, color: T.text }}>13</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>No-show rate</span><span style={{ fontFamily: T.mono, color: T.success }}>1.6%</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Reminders queued</span><span style={{ fontFamily: T.mono, color: T.text }}>47</span></div>
          </div>
        </div>
      </aside>
    </div>
  );
}

function iconBtnL(T) {
  return {
    width: 30, height: 30, borderRadius: 6, border: `1px solid ${T.border}`,
    background: T.surface, color: T.text, display: 'inline-flex',
    alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
    fontFamily: 'inherit', fontSize: 12, fontWeight: 500,
  };
}

window.Calendar = Calendar;
