// Dashboard.jsx — Direction A · clinic-wide pulse, messaging-forward

function Dashboard() {
  const T = ClinicalTokens;
  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex',
      background: T.bg, fontFamily: T.font, color: T.text, fontSize: 13,
    }}>
      <ClinicalSidebar2 active="Dashboard"/>

      <div style={{ flex: 1, overflow: 'auto' }}>
        <DashHeader T={T}/>

        <div style={{ padding: '24px 32px', display: 'flex', flexDirection: 'column', gap: 18 }}>
          <DashKPIs T={T}/>
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 18 }}>
            <DashInboxSnapshot T={T}/>
            <DashTodaySchedule T={T}/>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 18 }}>
            <DashTrends T={T}/>
            <DashFollowups T={T}/>
          </div>
        </div>
      </div>
    </div>
  );
}

// Reusable sidebar tuned for any active item
function ClinicalSidebar2({ active = 'Inbox' }) {
  const T = ClinicalTokens;
  const nav = [
    { icon: Icons.inbox, label: 'Inbox', badge: 12 },
    { icon: Icons.dashboard, label: 'Dashboard' },
    { icon: Icons.calendar, label: 'Calendar' },
    { icon: Icons.users, label: 'Patients' },
    { icon: Icons.megaphone, label: 'Campaigns' },
  ];
  return (
    <aside style={{
      width: 220, background: T.sidebar, color: T.sidebarText,
      display: 'flex', flexDirection: 'column', flexShrink: 0,
    }}>
      <div style={{ padding: '20px 18px 24px', display: 'flex', alignItems: 'center', gap: 9 }}>
        <div style={{
          width: 22, height: 22, borderRadius: 6, background: T.accent,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#0E1622', fontWeight: 800, fontSize: 13,
        }}>L</div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
          <span style={{ color: '#fff', fontWeight: 600 }}>Lumen</span>
          <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12 }}>CRM</span>
        </div>
      </div>

      <div style={{ padding: '0 10px' }}>
        <button style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 8,
          padding: '8px 10px', borderRadius: 7,
          background: 'rgba(255,255,255,0.08)', color: '#fff',
          border: '1px solid rgba(255,255,255,0.06)', fontSize: 13,
          fontFamily: 'inherit', cursor: 'pointer', justifyContent: 'space-between',
        }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Icons.plus size={14} strokeWidth={2}/> New message
          </span>
          <kbd style={{ fontSize: 10, fontFamily: T.mono, color: 'rgba(255,255,255,0.5)' }}>⌘N</kbd>
        </button>
      </div>

      <nav style={{ padding: '14px 8px', flex: 1, display: 'flex', flexDirection: 'column', gap: 1 }}>
        {nav.map((n, i) => {
          const Icn = n.icon;
          const isActive = n.label === active;
          return (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '7px 10px', borderRadius: 6, cursor: 'pointer',
              background: isActive ? T.sidebarActive : 'transparent',
              color: isActive ? T.sidebarTextActive : T.sidebarText,
              fontSize: 13.5, fontWeight: isActive ? 500 : 400,
              borderLeft: isActive ? `2px solid ${T.accent}` : '2px solid transparent',
              marginLeft: isActive ? -2 : 0,
            }}>
              <Icn size={16} strokeWidth={1.6}/>
              <span style={{ flex: 1 }}>{n.label}</span>
              {n.badge ? (
                <span style={{
                  fontSize: 11, padding: '1px 6px', borderRadius: 9,
                  background: isActive ? T.accent : 'rgba(255,255,255,0.1)',
                  color: isActive ? '#0E1622' : '#fff', fontWeight: 600, fontFamily: T.mono,
                }}>{n.badge}</span>
              ) : null}
            </div>
          );
        })}

        <div style={{ marginTop: 18, padding: '0 10px 6px', fontSize: 10.5, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 600 }}>Saved views</div>
        {['Unassigned · 4', 'No-show recovery · 3', 'Awaiting forms · 6', 'Birthdays this week'].map((v, i) => (
          <div key={i} style={{ padding: '6px 10px 6px 16px', fontSize: 12.5, color: 'rgba(255,255,255,0.55)', cursor: 'pointer' }}>{v}</div>
        ))}
      </nav>

      <div style={{ padding: 10, borderTop: '1px solid rgba(255,255,255,0.05)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 6 }}>
          <Avatar name="Jordan Kim" size={28} palette="C"/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ color: '#fff', fontSize: 12.5, fontWeight: 500 }}>Jordan Kim</div>
            <div style={{ color: 'rgba(255,255,255,0.45)', fontSize: 11 }}>Practice manager</div>
          </div>
          <Icons.settings size={14}/>
        </div>
      </div>
    </aside>
  );
}

function DashHeader({ T }) {
  return (
    <div style={{
      padding: '22px 32px 18px', borderBottom: `1px solid ${T.border}`,
      background: T.surface, display: 'flex', alignItems: 'center', gap: 16,
    }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11.5, color: T.textDim, fontFamily: T.mono, marginBottom: 4 }}>
          TUESDAY · MAY 22, 2026 · MAPLE FAMILY CLINIC
        </div>
        <h1 style={{ margin: 0, fontSize: 24, fontWeight: 600, color: T.text, letterSpacing: '-0.02em' }}>
          Good morning, Jordan
        </h1>
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button style={{
          padding: '8px 14px', borderRadius: 7, background: T.surface, color: T.text,
          border: `1px solid ${T.border}`, fontFamily: 'inherit', fontSize: 12.5, cursor: 'pointer',
          display: 'inline-flex', alignItems: 'center', gap: 6, fontWeight: 500,
        }}>
          <Icons.megaphone size={13}/> Start campaign
        </button>
        <button style={{
          padding: '8px 14px', borderRadius: 7, background: T.accent, color: '#fff',
          border: 'none', fontFamily: 'inherit', fontSize: 12.5, cursor: 'pointer',
          display: 'inline-flex', alignItems: 'center', gap: 6, fontWeight: 600,
        }}>
          <Icons.plus size={13} strokeWidth={2}/> New patient
        </button>
      </div>
    </div>
  );
}

function DashKPIs({ T }) {
  const kpis = [
    { label: 'Messages today', v: '47', delta: '+18%', good: true, sub: '12 awaiting reply', icon: Icons.chat },
    { label: 'Median reply time', v: '4m 12s', delta: '−1m 04s', good: true, sub: 'team SLA 10m', icon: Icons.clock },
    { label: 'Appointments', v: '28 / 31', delta: '90% booked', good: true, sub: '2 no-shows recovered', icon: Icons.calendar },
    { label: 'No-show risk', v: '4', delta: '3 outreach drafted', good: false, sub: 'thu + fri appts', icon: Icons.flag },
  ];
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
      {kpis.map((k, i) => {
        const Icn = k.icon;
        return (
          <div key={i} style={{
            background: T.surface, border: `1px solid ${T.border}`, borderRadius: 12,
            padding: '16px 18px', display: 'flex', flexDirection: 'column', gap: 6,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 11, color: T.textDim, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>{k.label}</span>
              <span style={{
                width: 26, height: 26, borderRadius: 6, background: T.accentSoft,
                color: T.accent, display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}><Icn size={14}/></span>
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 4 }}>
              <span style={{ fontSize: 28, fontWeight: 600, color: T.text, fontFamily: T.mono, letterSpacing: '-0.02em' }}>{k.v}</span>
              <span style={{ fontSize: 12, color: k.good ? T.success : T.warn, fontWeight: 500 }}>{k.delta}</span>
            </div>
            <div style={{ fontSize: 11.5, color: T.textFaint }}>{k.sub}</div>
          </div>
        );
      })}
    </div>
  );
}

function DashInboxSnapshot({ T }) {
  const rows = [
    { name: 'Maya Okafor', ch: 'sms', text: 'reschedule Thu 3pm → 5:30 same day?', time: '2m', urgent: true, ai: true },
    { name: 'Daniel Reyes', ch: 'whatsapp', text: 'fast 12h before blood draw?', time: '9m' },
    { name: 'Aisha Patel', ch: 'sms', text: 'insurance card uploaded', time: '14m', attach: true },
    { name: 'Marcus Lin', ch: 'sms', text: 'no-show 10am — outreach drafted', time: '1h', urgent: true, ai: true },
    { name: 'Priya Ramaswamy', ch: 'voice', text: 'voicemail · new patient', time: '2h' },
    { name: 'Hugo Pereira', ch: 'whatsapp', text: 'rx refill: metformin', time: '6h' },
  ];
  return (
    <div style={{ background: T.surface, border: `1px solid ${T.border}`, borderRadius: 12 }}>
      <div style={{ padding: '14px 18px', borderBottom: `1px solid ${T.border}`, display: 'flex', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 14, fontWeight: 600, color: T.text }}>Inbox snapshot</div>
          <div style={{ fontSize: 11.5, color: T.textDim, marginTop: 2 }}>What needs you in the next hour</div>
        </div>
        <button style={{ marginLeft: 'auto', fontSize: 12, color: T.accent, background: 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontWeight: 600 }}>
          Open inbox →
        </button>
      </div>
      <div>
        {rows.map((r, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '10px 18px', borderBottom: i < rows.length - 1 ? `1px solid ${T.border}` : 'none',
          }}>
            <Avatar name={r.name} size={28} palette="A"/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12.5, fontWeight: 500, color: T.text, marginBottom: 1, display: 'flex', alignItems: 'center', gap: 6 }}>
                {r.name}
                {r.urgent ? <span style={{ fontSize: 9.5, padding: '0 5px', borderRadius: 3, background: '#FBE8E5', color: T.danger, fontFamily: T.mono, fontWeight: 600 }}>URGENT</span> : null}
                {r.ai ? <span style={{ fontSize: 9.5, color: T.accent, fontFamily: T.mono, fontWeight: 600 }}>✨ DRAFTED</span> : null}
                {r.attach ? <Icons.paperclip size={10} stroke={T.textFaint}/> : null}
              </div>
              <div style={{ fontSize: 11.5, color: T.textDim, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.text}</div>
            </div>
            <ChannelDot channel={r.ch} size={11}/>
            <span style={{ fontSize: 10.5, color: T.textFaint, fontFamily: T.mono, width: 28, textAlign: 'right' }}>{r.time}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function DashTodaySchedule({ T }) {
  const slots = [
    { time: '8:30', name: 'Daniel Reyes', type: 'Blood draw', status: 'arrived' },
    { time: '9:00', name: 'Aisha Patel', type: 'New patient', status: 'confirmed' },
    { time: '9:30', name: 'Sofia Bianchi', type: 'Follow-up', status: 'confirmed' },
    { time: '10:00', name: 'Marcus Lin', type: 'Annual physical', status: 'no-show' },
    { time: '10:30', name: 'Owen Carter', type: 'Vaccination', status: 'in-room' },
    { time: '11:00', name: '—', type: 'Open', status: 'open' },
    { time: '11:30', name: 'Sam Chen (peds)', type: 'Sick visit', status: 'confirmed' },
  ];
  const statusColor = {
    arrived: { bg: T.accentSoft, fg: T.accent, label: 'Arrived' },
    confirmed: { bg: '#F0EEE7', fg: T.textDim, label: 'Confirmed' },
    'no-show': { bg: '#FBE8E5', fg: T.danger, label: 'No-show' },
    'in-room': { bg: '#E6F2EA', fg: T.success, label: 'In room' },
    open: { bg: 'transparent', fg: T.textFaint, label: 'Open' },
  };
  return (
    <div style={{ background: T.surface, border: `1px solid ${T.border}`, borderRadius: 12 }}>
      <div style={{ padding: '14px 18px', borderBottom: `1px solid ${T.border}`, display: 'flex', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 14, fontWeight: 600 }}>Today · Dr. Lin</div>
          <div style={{ fontSize: 11.5, color: T.textDim, marginTop: 2 }}>7 booked · 1 open · 1 no-show</div>
        </div>
        <button style={{ marginLeft: 'auto', fontSize: 12, color: T.accent, background: 'transparent', border: 'none', cursor: 'pointer', fontWeight: 600 }}>
          Calendar →
        </button>
      </div>
      <div>
        {slots.map((s, i) => {
          const sc = statusColor[s.status];
          const isCurrent = s.time === '10:30';
          return (
            <div key={i} style={{
              display: 'flex', gap: 10, padding: '8px 18px',
              borderBottom: i < slots.length - 1 ? `1px solid ${T.border}` : 'none',
              background: isCurrent ? T.accentSoft : 'transparent',
              borderLeft: isCurrent ? `2px solid ${T.accent}` : '2px solid transparent',
              alignItems: 'center',
            }}>
              <span style={{ fontFamily: T.mono, fontSize: 11.5, color: T.textDim, width: 38 }}>{s.time}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12.5, fontWeight: s.status === 'open' ? 400 : 500, color: s.status === 'open' ? T.textFaint : T.text }}>
                  {s.name}
                </div>
                <div style={{ fontSize: 11, color: T.textFaint }}>{s.type}</div>
              </div>
              <span style={{
                fontSize: 10, padding: '2px 8px', borderRadius: 4,
                background: sc.bg, color: sc.fg, fontWeight: 600,
                border: s.status === 'open' ? `1px dashed ${T.border}` : 'none',
              }}>{sc.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DashTrends({ T }) {
  // 14-day sparkline-ish bar chart of messages/day
  const data = [22, 28, 31, 18, 25, 41, 38, 24, 33, 29, 47, 39, 44, 47];
  const max = Math.max(...data);
  return (
    <div style={{ background: T.surface, border: `1px solid ${T.border}`, borderRadius: 12, padding: '14px 18px 16px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', marginBottom: 12 }}>
        <div>
          <div style={{ fontSize: 14, fontWeight: 600 }}>Messaging volume</div>
          <div style={{ fontSize: 11.5, color: T.textDim, marginTop: 2 }}>Last 14 days · by channel</div>
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 12, alignItems: 'center' }}>
          {[['SMS', T.accent], ['WhatsApp', '#5B8C5A'], ['Email', '#7A5C9A']].map(([l, c], i) => (
            <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11, color: T.textDim }}>
              <span style={{ width: 8, height: 8, borderRadius: 2, background: c }}/> {l}
            </span>
          ))}
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 120, marginBottom: 8 }}>
        {data.map((d, i) => (
          <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 1.5, justifyContent: 'flex-end' }}>
            <div style={{ height: `${(d * 0.4 / max) * 100}%`, background: '#7A5C9A', borderRadius: '2px 2px 0 0', opacity: 0.55 }}/>
            <div style={{ height: `${(d * 0.25 / max) * 100}%`, background: '#5B8C5A', opacity: 0.75 }}/>
            <div style={{ height: `${(d * 0.35 / max) * 100}%`, background: T.accent, borderRadius: i === 13 ? 0 : '0 0 2px 2px' }}/>
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: T.textFaint, fontFamily: T.mono }}>
        <span>May 09</span><span>May 13</span><span>May 17</span><span>May 22 ·today</span>
      </div>
    </div>
  );
}

function DashFollowups({ T }) {
  const items = [
    { tag: 'No-show recovery', count: 3, label: 'Marcus, Greg, Hannah', cta: 'Send draft' },
    { tag: 'Pre-visit reminders', count: 8, label: 'Tomorrow 9am', cta: 'Schedule' },
    { tag: 'Lab follow-ups', count: 5, label: 'Past 7 days', cta: 'Review' },
    { tag: 'Birthday greetings', count: 4, label: 'This week', cta: 'Auto-send' },
    { tag: 'Annual exam due', count: 12, label: 'Apr–Jun ‘25 cohort', cta: 'Start campaign' },
  ];
  return (
    <div style={{ background: T.surface, border: `1px solid ${T.border}`, borderRadius: 12 }}>
      <div style={{ padding: '14px 18px', borderBottom: `1px solid ${T.border}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Icons.sparkles size={14} stroke={T.accent}/>
          <div style={{ fontSize: 14, fontWeight: 600 }}>Suggested follow-ups</div>
        </div>
        <div style={{ fontSize: 11.5, color: T.textDim, marginTop: 2 }}>Lumen sees these patients are due for outreach</div>
      </div>
      {items.map((it, i) => (
        <div key={i} style={{
          padding: '10px 18px', borderBottom: i < items.length - 1 ? `1px solid ${T.border}` : 'none',
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{
            width: 28, height: 28, borderRadius: 7, background: T.accentSoft, color: T.accent,
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontFamily: T.mono, fontSize: 12,
          }}>{it.count}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12.5, fontWeight: 500, color: T.text }}>{it.tag}</div>
            <div style={{ fontSize: 11, color: T.textFaint }}>{it.label}</div>
          </div>
          <button style={{
            fontSize: 11.5, padding: '4px 11px', borderRadius: 5,
            background: T.surface, color: T.text, border: `1px solid ${T.border}`,
            cursor: 'pointer', fontFamily: 'inherit', fontWeight: 500,
          }}>{it.cta}</button>
        </div>
      ))}
    </div>
  );
}

window.Dashboard = Dashboard;
window.ClinicalSidebar2 = ClinicalSidebar2;
