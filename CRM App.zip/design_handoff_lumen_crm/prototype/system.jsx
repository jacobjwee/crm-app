// system.jsx — shared icons + small helpers used across screens.
// All icons are 1.5px stroke, 20×20 viewBox. Keep them stylistically consistent.

const Icon = ({ d, size = 18, stroke = 'currentColor', fill = 'none', strokeWidth = 1.5, ...rest }) => (
  <svg width={size} height={size} viewBox="0 0 20 20" fill={fill} stroke={stroke}
    strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" {...rest}>
    {d}
  </svg>
);

const Icons = {
  inbox: (p) => <Icon {...p} d={<><path d="M3 11.5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v6.5"/><path d="M3 11.5h4l1.2 2h3.6l1.2-2h4v3.5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3.5Z"/></>} />,
  chat: (p) => <Icon {...p} d={<><path d="M3 4.5A1.5 1.5 0 0 1 4.5 3h11A1.5 1.5 0 0 1 17 4.5v8A1.5 1.5 0 0 1 15.5 14H8l-3.5 3v-3h-.5A1.5 1.5 0 0 1 2.5 12.5v-8Z" transform="translate(.5 0)"/></>} />,
  calendar: (p) => <Icon {...p} d={<><rect x="3" y="4.5" width="14" height="12.5" rx="1.5"/><path d="M3 8h14"/><path d="M7 3v3M13 3v3"/></>} />,
  users: (p) => <Icon {...p} d={<><circle cx="7.5" cy="7.5" r="2.5"/><path d="M3 16c.4-2.5 2.3-4 4.5-4S11.6 13.5 12 16"/><circle cx="13.5" cy="6.5" r="2"/><path d="M14 12c1.7.2 3 1.5 3.5 4"/></>} />,
  user: (p) => <Icon {...p} d={<><circle cx="10" cy="7.5" r="2.7"/><path d="M4.5 16.5c.6-2.8 2.7-4.5 5.5-4.5s4.9 1.7 5.5 4.5"/></>} />,
  megaphone: (p) => <Icon {...p} d={<><path d="M4 8v4a1 1 0 0 0 1 1h2l5 3V4L7 7H5a1 1 0 0 0-1 1Z"/><path d="M14 7c1 .8 1.5 1.8 1.5 3s-.5 2.2-1.5 3"/></>} />,
  dashboard: (p) => <Icon {...p} d={<><rect x="3" y="3" width="6" height="9" rx="1"/><rect x="3" y="14" width="6" height="3" rx="1"/><rect x="11" y="3" width="6" height="3" rx="1"/><rect x="11" y="8" width="6" height="9" rx="1"/></>} />,
  settings: (p) => <Icon {...p} d={<><circle cx="10" cy="10" r="2.5"/><path d="M10 2.5v2M10 15.5v2M17.5 10h-2M4.5 10h-2M15.3 4.7l-1.4 1.4M6.1 13.9l-1.4 1.4M15.3 15.3l-1.4-1.4M6.1 6.1L4.7 4.7"/></>} />,
  search: (p) => <Icon {...p} d={<><circle cx="9" cy="9" r="5"/><path d="M13 13l4 4"/></>} />,
  send: (p) => <Icon {...p} d={<><path d="M3 10 17 4 11 17l-2-6-6-1Z"/></>} />,
  paperclip: (p) => <Icon {...p} d={<path d="M14.5 8.5 9 14a3 3 0 0 1-4.2-4.2l6-6a2 2 0 1 1 2.8 2.8L7.7 12.3a1 1 0 1 1-1.4-1.4l5.2-5.2"/>} />,
  plus: (p) => <Icon {...p} d={<><path d="M10 4v12M4 10h12"/></>} />,
  chevronDown: (p) => <Icon {...p} d={<path d="m5 8 5 5 5-5"/>} />,
  chevronRight: (p) => <Icon {...p} d={<path d="m8 5 5 5-5 5"/>} />,
  chevronLeft: (p) => <Icon {...p} d={<path d="m12 5-5 5 5 5"/>} />,
  more: (p) => <Icon {...p} d={<><circle cx="5" cy="10" r=".8" fill="currentColor"/><circle cx="10" cy="10" r=".8" fill="currentColor"/><circle cx="15" cy="10" r=".8" fill="currentColor"/></>} />,
  star: (p) => <Icon {...p} d={<path d="m10 3 2.2 4.5 4.8.7-3.5 3.4.9 4.9-4.4-2.3-4.4 2.3.9-4.9L3 8.2l4.8-.7L10 3Z"/>} />,
  bell: (p) => <Icon {...p} d={<><path d="M5 14V9a5 5 0 0 1 10 0v5l1.5 1.5h-13L5 14Z"/><path d="M8.5 17a1.5 1.5 0 0 0 3 0"/></>} />,
  filter: (p) => <Icon {...p} d={<path d="M3 5h14l-5.5 6v5l-3 1.5V11L3 5Z"/>} />,
  phone: (p) => <Icon {...p} d={<path d="M5 3.5h2.5l1.5 4-2 1.2a8 8 0 0 0 4.3 4.3L12.5 11l4 1.5V15a1.5 1.5 0 0 1-1.7 1.5C8.7 16 4 11.3 3.5 5.2A1.5 1.5 0 0 1 5 3.5Z"/>} />,
  mail: (p) => <Icon {...p} d={<><rect x="3" y="5" width="14" height="10" rx="1.5"/><path d="m3.5 6 6.5 5 6.5-5"/></>} />,
  sms: (p) => <Icon {...p} d={<path d="M3 5.5A1.5 1.5 0 0 1 4.5 4h11A1.5 1.5 0 0 1 17 5.5v6A1.5 1.5 0 0 1 15.5 13H9l-4 3v-3A1.5 1.5 0 0 1 4.5 11.5l-1.5 0 0-6Z"/>} />,
  whatsapp: (p) => <Icon {...p} d={<><path d="M3.5 16.5 4.7 13a6.5 6.5 0 1 1 2.7 2.6L3.5 16.5Z"/><path d="M7.5 8.5c.3 1.5 1.5 2.7 3 3l.7-.7c.3-.3.7-.4 1.1-.2l1.2.5c.4.2.6.6.5 1 0 0-.3 1.2-1.5 1.4-2 .3-5.3-1.8-5.6-4 0 0 .1-1.4 1.4-1.5.5 0 .8.2.9.6l.4 1.2c.1.4 0 .8-.2 1.1l-.6.6"/></>} />,
  check: (p) => <Icon {...p} d={<path d="m4 10 4 4 8-9"/>} />,
  checkCircle: (p) => <Icon {...p} d={<><circle cx="10" cy="10" r="7.5"/><path d="m6.5 10 2.5 2.5L14 8"/></>} />,
  clock: (p) => <Icon {...p} d={<><circle cx="10" cy="10" r="7"/><path d="M10 6v4l2.5 1.5"/></>} />,
  sparkles: (p) => <Icon {...p} d={<><path d="M10 3v3M10 14v3M3 10h3M14 10h3M5 5l2 2M13 13l2 2M5 15l2-2M13 7l2-2"/></>} />,
  bolt: (p) => <Icon {...p} d={<path d="M11 2 4 11h5l-1 7 7-9h-5l1-7Z"/>} />,
  tag: (p) => <Icon {...p} d={<><path d="M3 3v6l8 8 6-6-8-8H3Z"/><circle cx="6.5" cy="6.5" r=".8" fill="currentColor"/></>} />,
  archive: (p) => <Icon {...p} d={<><rect x="3" y="4" width="14" height="3" rx="1"/><path d="M4 7v8a1.5 1.5 0 0 0 1.5 1.5h9A1.5 1.5 0 0 0 16 15V7"/><path d="M8 11h4"/></>} />,
  trash: (p) => <Icon {...p} d={<><path d="M3.5 5.5h13M8 5.5V4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v1.5"/><path d="M5 5.5v10a1.5 1.5 0 0 0 1.5 1.5h7A1.5 1.5 0 0 0 15 15.5v-10"/></>} />,
  edit: (p) => <Icon {...p} d={<path d="M3 17h3l9-9-3-3-9 9v3ZM12 5l3 3"/>} />,
  link: (p) => <Icon {...p} d={<><path d="M9 11l2-2M7.5 13.5l-2 2a2.5 2.5 0 0 1-3.5-3.5l3-3a2.5 2.5 0 0 1 3.5 0"/><path d="M12.5 6.5l2-2a2.5 2.5 0 0 1 3.5 3.5l-3 3a2.5 2.5 0 0 1-3.5 0"/></>} />,
  pin: (p) => <Icon {...p} d={<><path d="M10 3v6l-3 2v2h6v-2l-3-2"/><path d="M10 13v4"/></>} />,
  flag: (p) => <Icon {...p} d={<><path d="M4 3v14"/><path d="M4 4h9l-2 3 2 3H4"/></>} />,
};

// Avatar with consistent hue derived from name
function Avatar({ name, size = 36, src, ring, palette = 'A' }) {
  const initials = (name || '?').split(' ').map(s => s[0]).slice(0, 2).join('').toUpperCase();
  const hue = [...(name || '')].reduce((a, c) => a + c.charCodeAt(0), 0) * 37 % 360;
  const palettes = {
    A: `oklch(0.78 0.06 ${hue})`,  // clinical: pastel
    B: `oklch(0.74 0.08 ${hue})`,  // warm: a bit more chroma
    C: `oklch(0.55 0.10 ${hue})`,  // dense: deeper
  };
  const bg = palettes[palette] || palettes.A;
  const fg = palette === 'C' ? '#fff' : '#1a1410';
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%', background: bg, color: fg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontWeight: 600, fontSize: size * 0.36, flexShrink: 0,
      boxShadow: ring ? `0 0 0 2px ${ring}` : undefined,
      fontFamily: 'inherit', letterSpacing: '-0.02em',
    }}>
      {initials}
    </div>
  );
}

// Channel badge
function ChannelDot({ channel, size = 14 }) {
  const map = {
    sms: { bg: '#dbeafe', fg: '#1e40af', icon: Icons.sms },
    whatsapp: { bg: '#d1fae5', fg: '#065f46', icon: Icons.whatsapp },
    email: { bg: '#ede9fe', fg: '#5b21b6', icon: Icons.mail },
    chat: { bg: '#fef3c7', fg: '#92400e', icon: Icons.chat },
    voice: { bg: '#fee2e2', fg: '#991b1b', icon: Icons.phone },
  };
  const c = map[channel] || map.sms;
  const Icn = c.icon;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      width: size + 6, height: size + 6, borderRadius: 4,
      background: c.bg, color: c.fg, flexShrink: 0,
    }}>
      <Icn size={size - 2} strokeWidth={1.7} />
    </span>
  );
}

Object.assign(window, { Icon, Icons, Avatar, ChannelDot });
