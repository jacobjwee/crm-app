// InboxClinical.jsx — Direction A: Clinical Calm
// Evolution of the existing CRM. Navy sidebar, warm-white surfaces, teal accent.
// Font: Geist + Geist Mono.

const ClinicalTokens = {
  font: "'Geist', system-ui, sans-serif",
  mono: "'Geist Mono', ui-monospace, monospace",
  bg: '#F6F5F1',        // warm off-white surface
  surface: '#FFFFFF',
  surfaceAlt: '#FAF9F5',
  border: '#E7E4DC',
  borderStrong: '#D9D5CB',
  text: '#0F1419',
  textDim: '#5C6470',
  textFaint: '#94A0AE',
  sidebar: '#0E1622',   // deeper navy than current, but same family
  sidebarText: 'rgba(255,255,255,0.7)',
  sidebarTextActive: '#FFFFFF',
  sidebarHover: 'rgba(255,255,255,0.06)',
  sidebarActive: 'rgba(83,178,168,0.18)',
  accent: '#2E8C82',    // calm teal
  accentSoft: '#E5F1EF',
  danger: '#C3463A',
  warn: '#B6792B',
  success: '#3E8C5A',
};

// -- Threads + messages mock data ---------------------------------------------

const ClinicalThreads = [
  { id: 't1', name: 'Maya Okafor', preview: 'Hi, can I move my Thursday 3pm? Something came up at work and I…', time: '2m', unread: 2, channel: 'sms', tags: ['Reschedule'], assigned: 'me', pinned: true, ai: true, snippet: 'reschedule request', active: true },
  { id: 't2', name: 'Daniel Reyes', preview: 'Thanks! Just confirming I should fast 12hrs before the blood draw?', time: '9m', unread: 1, channel: 'whatsapp', tags: ['Pre-visit'], assigned: 'me' },
  { id: 't3', name: 'Aisha Patel', preview: 'Insurance card uploaded. Let me know if you need a different angle.', time: '14m', unread: 0, channel: 'sms', tags: ['Intake'], assigned: 'Jordan K.', attachment: true },
  { id: 't4', name: 'Greg Hollister', preview: 'Auto-reply: We received your message. A team member will reply…', time: '22m', unread: 0, channel: 'email', tags: ['Billing'], assigned: 'Jordan K.', auto: true },
  { id: 't5', name: 'Sofia Bianchi', preview: 'Felt much better after the new prescription. Quick question on side…', time: '38m', unread: 0, channel: 'sms', tags: ['Follow-up'], assigned: 'me' },
  { id: 't6', name: 'Marcus Lin', preview: 'No-show flag — appt was today 10:00. Suggested follow-up draft ready.', time: '1h', unread: 1, channel: 'sms', tags: ['No-show'], assigned: 'unassigned', ai: true, flagged: true },
  { id: 't7', name: 'Priya Ramaswamy', preview: 'Voice message · 0:43 — transcript: "Hi, I was hoping to schedule…"', time: '2h', unread: 0, channel: 'voice', tags: ['New patient'], assigned: 'unassigned' },
  { id: 't8', name: 'Owen Carter', preview: 'Confirmed for Monday at 2:15pm. See you then 👋', time: '3h', unread: 0, channel: 'sms', tags: [], assigned: 'me', sent: true },
  { id: 't9', name: 'Rebecca Wu', preview: 'Form completed: New Patient Intake (4 pages). Ready for review.', time: '4h', unread: 0, channel: 'email', tags: ['Forms'], assigned: 'Jordan K.' },
  { id: 't10', name: 'Family of Sam Chen', preview: 'Hi, this is Sam\'s mom — wanted to check what to bring for the visit', time: 'Yest.', unread: 0, channel: 'sms', tags: ['Guardian'], assigned: 'me' },
];

const ClinicalConversation = [
  { from: 'patient', text: 'Hi! I had my 6-month checkup last week and just got the lab results in the portal. The cholesterol number looks a bit higher than last year — is that something we should chat about?', time: 'Yesterday · 4:42 PM' },
  { from: 'system', text: 'Dr. Lin reviewed labs · added note "Mild LDL increase, recommend dietary follow-up in 3mo"', time: 'Yesterday · 6:10 PM' },
  { from: 'staff', author: 'You', text: 'Hi Maya — totally normal to want to check in on that. Dr. Lin saw the labs and noted it\'s a mild increase, not urgent. We can either book a 15-min video follow-up next week, or revisit at your next physical in 6 months. What feels right?', time: 'Yesterday · 6:48 PM' },
  { from: 'patient', text: 'Let\'s do the video follow-up, that would put my mind at ease. Thursday afternoon could work?', time: 'Yesterday · 7:01 PM' },
  { from: 'staff', author: 'You', text: 'Booked you in for Thursday May 28 at 3:00 PM with Dr. Lin (video). You\'ll get a Zoom link 30 min before. Anything else?', time: 'Yesterday · 7:04 PM', sentBy: 'sms' },
  { from: 'patient', text: 'Hi, can I move my Thursday 3pm? Something came up at work and I might not be home in time. Would 5:30 same day work?', time: 'Today · 9:12 AM', unread: true },
];

// -- Components ---------------------------------------------------------------

function ClinicalSidebar() {
  const T = ClinicalTokens;
  const nav = [
    { icon: Icons.inbox, label: 'Inbox', badge: 12, active: true },
    { icon: Icons.dashboard, label: 'Dashboard' },
    { icon: Icons.calendar, label: 'Calendar' },
    { icon: Icons.users, label: 'Patients' },
    { icon: Icons.megaphone, label: 'Campaigns' },
  ];
  return (
    <aside style={{
      width: 220, background: T.sidebar, color: T.sidebarText,
      display: 'flex', flexDirection: 'column', flexShrink: 0,
      borderRight: '1px solid rgba(255,255,255,0.04)',
    }}>
      <div style={{ padding: '20px 18px 24px', display: 'flex', alignItems: 'center', gap: 9 }}>
        <div style={{
          width: 22, height: 22, borderRadius: 6, background: T.accent,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#0E1622', fontWeight: 800, fontSize: 13,
        }}>L</div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
          <span style={{ color: '#fff', fontWeight: 600, letterSpacing: '-0.01em' }}>Lumen</span>
          <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12 }}>CRM</span>
        </div>
      </div>

      <div style={{ padding: '0 10px' }}>
        <button style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 8,
          padding: '8px 10px', borderRadius: 7,
          background: 'rgba(255,255,255,0.08)', color: '#fff',
          border: '1px solid rgba(255,255,255,0.06)', fontSize: 13,
          fontFamily: 'inherit', cursor: 'pointer', justifyContent: 'space-between',
        }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Icons.plus size={14} strokeWidth={2}/> New message
          </span>
          <kbd style={{ fontSize: 10, fontFamily: T.mono, color: 'rgba(255,255,255,0.5)' }}>⌘N</kbd>
        </button>
      </div>

      <nav style={{ padding: '14px 8px', flex: 1, display: 'flex', flexDirection: 'column', gap: 1 }}>
        {nav.map((n, i) => {
          const Icn = n.icon;
          return (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '7px 10px', borderRadius: 6, cursor: 'pointer',
              background: n.active ? T.sidebarActive : 'transparent',
              color: n.active ? T.sidebarTextActive : T.sidebarText,
              fontSize: 13.5, fontWeight: n.active ? 500 : 400,
              borderLeft: n.active ? `2px solid ${T.accent}` : '2px solid transparent',
              marginLeft: n.active ? -2 : 0,
            }}>
              <Icn size={16} strokeWidth={1.6}/>
              <span style={{ flex: 1 }}>{n.label}</span>
              {n.badge ? (
                <span style={{
                  fontSize: 11, padding: '1px 6px', borderRadius: 9,
                  background: n.active ? T.accent : 'rgba(255,255,255,0.1)',
                  color: n.active ? '#0E1622' : '#fff', fontWeight: 600,
                  fontFamily: T.mono,
                }}>{n.badge}</span>
              ) : null}
            </div>
          );
        })}

        <div style={{ marginTop: 18, padding: '0 10px 6px', fontSize: 10.5, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 600 }}>Saved views</div>
        {['Unassigned · 4', 'No-show recovery · 3', 'Awaiting forms · 6', 'Birthdays this week'].map((v, i) => (
          <div key={i} style={{ padding: '6px 10px 6px 16px', fontSize: 12.5, color: 'rgba(255,255,255,0.55)', cursor: 'pointer', borderRadius: 6 }}>{v}</div>
        ))}
      </nav>

      <div style={{ padding: 10, borderTop: '1px solid rgba(255,255,255,0.05)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 6 }}>
          <Avatar name="Jordan Kim" size={28} palette="C"/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ color: '#fff', fontSize: 12.5, fontWeight: 500 }}>Jordan Kim</div>
            <div style={{ color: 'rgba(255,255,255,0.45)', fontSize: 11 }}>Practice manager</div>
          </div>
          <Icons.settings size={14}/>
        </div>
      </div>
    </aside>
  );
}

function ClinicalThreadList() {
  const T = ClinicalTokens;
  const filters = ['All · 142', 'Unread · 12', 'Assigned to me · 28', 'Unassigned · 4', 'Escalated · 2'];
  return (
    <div style={{
      width: 340, background: T.surfaceAlt, borderRight: `1px solid ${T.border}`,
      display: 'flex', flexDirection: 'column', flexShrink: 0,
    }}>
      <div style={{ padding: '16px 18px 12px', borderBottom: `1px solid ${T.border}` }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <h2 style={{ margin: 0, fontSize: 17, color: T.text, fontWeight: 600, letterSpacing: '-0.01em' }}>Inbox</h2>
          <div style={{ display: 'flex', gap: 4 }}>
            <button style={iconBtn(T)}><Icons.filter size={14}/></button>
            <button style={iconBtn(T)}><Icons.more size={14}/></button>
          </div>
        </div>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8, padding: '7px 10px',
          background: T.surface, border: `1px solid ${T.border}`, borderRadius: 7,
        }}>
          <Icons.search size={13} stroke={T.textFaint}/>
          <input placeholder="Search messages, patients, threads…" style={{
            border: 0, outline: 0, background: 'transparent', fontFamily: 'inherit',
            fontSize: 12.5, color: T.text, width: '100%',
          }}/>
          <kbd style={{ fontSize: 10, fontFamily: T.mono, color: T.textFaint, padding: '1px 5px', border: `1px solid ${T.border}`, borderRadius: 3 }}>/</kbd>
        </div>
      </div>

      <div style={{ padding: '8px 10px', display: 'flex', gap: 4, flexWrap: 'wrap', borderBottom: `1px solid ${T.border}` }}>
        {filters.map((f, i) => (
          <span key={i} style={{
            fontSize: 11, padding: '4px 8px', borderRadius: 6,
            background: i === 1 ? T.accentSoft : 'transparent',
            color: i === 1 ? T.accent : T.textDim,
            border: `1px solid ${i === 1 ? T.accentSoft : T.border}`,
            cursor: 'pointer', fontWeight: i === 1 ? 600 : 500,
          }}>{f}</span>
        ))}
      </div>

      <div style={{ flex: 1, overflow: 'auto' }}>
        {ClinicalThreads.map((t) => (
          <ClinicalThreadRow key={t.id} t={t}/>
        ))}
      </div>
    </div>
  );
}

function ClinicalThreadRow({ t }) {
  const T = ClinicalTokens;
  return (
    <div style={{
      display: 'flex', gap: 11, padding: '11px 14px',
      borderBottom: `1px solid ${T.border}`,
      background: t.active ? T.surface : 'transparent',
      borderLeft: t.active ? `2px solid ${T.accent}` : '2px solid transparent',
      position: 'relative', cursor: 'pointer',
    }}>
      <Avatar name={t.name} size={32} palette="A"/>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 2 }}>
          <span style={{ fontWeight: t.unread ? 600 : 500, fontSize: 13, color: T.text, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {t.name}
          </span>
          <span style={{ fontSize: 10.5, color: T.textFaint, fontFamily: T.mono }}>{t.time}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 4 }}>
          <ChannelDot channel={t.channel} size={12}/>
          {t.ai ? (
            <span style={{ fontSize: 10, color: T.accent, fontWeight: 600, letterSpacing: '0.03em', display: 'inline-flex', alignItems: 'center', gap: 2 }}>
              <Icons.sparkles size={10} strokeWidth={1.8}/> AI
            </span>
          ) : null}
          {t.flagged ? <Icons.flag size={11} stroke={T.danger}/> : null}
          {t.attachment ? <Icons.paperclip size={11} stroke={T.textFaint}/> : null}
        </div>
        <div style={{
          fontSize: 12, color: t.unread ? T.text : T.textDim,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          lineHeight: 1.4, fontWeight: t.unread ? 500 : 400,
        }}>
          {t.preview}
        </div>
        <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
          {t.tags.map((tag, i) => (
            <span key={i} style={{
              fontSize: 10, padding: '1px 6px', borderRadius: 3,
              background: '#F0EEE7', color: T.textDim, fontWeight: 500,
              border: `1px solid ${T.border}`,
            }}>{tag}</span>
          ))}
          {t.assigned === 'me' ? null : (
            <span style={{ fontSize: 10, color: T.textFaint, marginLeft: 'auto' }}>
              {t.assigned === 'unassigned' ? '⚠ Unassigned' : `→ ${t.assigned}`}
            </span>
          )}
        </div>
      </div>
      {t.unread ? (
        <span style={{
          position: 'absolute', top: 14, right: 14,
          minWidth: 18, height: 18, padding: '0 5px', borderRadius: 9,
          background: T.accent, color: '#fff', fontSize: 10,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontWeight: 600, fontFamily: T.mono,
        }}>{t.unread}</span>
      ) : null}
    </div>
  );
}

function ClinicalConversationPane() {
  const T = ClinicalTokens;
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: T.surface, minWidth: 0 }}>
      {/* header */}
      <div style={{
        padding: '14px 22px', borderBottom: `1px solid ${T.border}`,
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <Avatar name="Maya Okafor" size={36} palette="A"/>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 15, fontWeight: 600, color: T.text, letterSpacing: '-0.01em' }}>Maya Okafor</span>
            <span style={{ fontSize: 11, color: T.textDim, padding: '2px 6px', borderRadius: 4, background: T.surfaceAlt, border: `1px solid ${T.border}` }}>
              Patient · 8 yrs
            </span>
          </div>
          <div style={{ fontSize: 11.5, color: T.textDim, marginTop: 2, display: 'flex', alignItems: 'center', gap: 6 }}>
            <ChannelDot channel="sms" size={10}/>
            <span>(415) 555-0149</span>
            <span>·</span>
            <span>Provider: Dr. Lin</span>
            <span>·</span>
            <span style={{ color: T.success }}>● Online 2m ago</span>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button style={iconBtn(T)}><Icons.phone size={14}/></button>
          <button style={iconBtn(T)}><Icons.calendar size={14}/></button>
          <button style={iconBtn(T)}><Icons.star size={14}/></button>
          <button style={iconBtn(T)}><Icons.more size={14}/></button>
        </div>
      </div>

      {/* messages */}
      <div style={{ flex: 1, overflow: 'auto', padding: '20px 22px 12px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={{ alignSelf: 'center', fontSize: 11, color: T.textFaint, padding: '3px 10px', borderRadius: 10, background: T.surfaceAlt }}>
          Yesterday
        </div>
        {ClinicalConversation.map((m, i) => <ClinicalBubble key={i} m={m}/>)}
        <div style={{ alignSelf: 'center', fontSize: 11, color: T.textFaint, padding: '3px 10px', borderRadius: 10, background: T.surfaceAlt }}>
          Today · 9:12 AM
        </div>
      </div>

      {/* AI suggestion strip */}
      <ClinicalAISuggestion/>

      {/* composer */}
      <div style={{ padding: '12px 18px 16px', borderTop: `1px solid ${T.border}` }}>
        <div style={{
          border: `1px solid ${T.borderStrong}`, borderRadius: 10, background: T.surface,
          padding: 4,
        }}>
          <div style={{ padding: '8px 12px 4px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 11, fontWeight: 600, color: T.textDim, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Reply via</span>
            <button style={{ ...chip(T), background: T.accentSoft, color: T.accent, borderColor: T.accentSoft }}>
              <ChannelDot channel="sms" size={10}/> SMS
            </button>
            <button style={chip(T)}>WhatsApp</button>
            <button style={chip(T)}>Email</button>
            <span style={{ marginLeft: 'auto', fontSize: 11, color: T.textFaint, fontFamily: T.mono }}>0 / 160</span>
          </div>
          <textarea placeholder="Write a reply, or press / for templates…" style={{
            width: '100%', border: 0, outline: 0, resize: 'none', background: 'transparent',
            padding: '6px 12px 8px', fontFamily: 'inherit', fontSize: 13.5,
            color: T.text, minHeight: 56, lineHeight: 1.5,
          }} defaultValue=""/>
          <div style={{ display: 'flex', alignItems: 'center', padding: '6px 8px 6px 8px', borderTop: `1px solid ${T.border}` }}>
            <div style={{ display: 'flex', gap: 2 }}>
              <button style={iconBtn(T)}><Icons.paperclip size={14}/></button>
              <button style={iconBtn(T)}><Icons.calendar size={14}/></button>
              <button style={iconBtn(T)}><Icons.tag size={14}/></button>
              <button style={iconBtn(T)}><Icons.sparkles size={14}/></button>
            </div>
            <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8 }}>
              <button style={{ ...chip(T), border: 'none', background: 'transparent', color: T.textDim }}>Save draft</button>
              <button style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                padding: '7px 14px', background: T.accent, color: '#fff', border: 'none',
                borderRadius: 7, fontFamily: 'inherit', fontSize: 12.5, fontWeight: 600, cursor: 'pointer',
              }}>
                Send <Icons.send size={13} strokeWidth={2}/>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ClinicalBubble({ m }) {
  const T = ClinicalTokens;
  if (m.from === 'system') {
    return (
      <div style={{
        alignSelf: 'center', fontSize: 11.5, color: T.textDim,
        padding: '5px 12px', background: T.surfaceAlt, borderRadius: 12,
        border: `1px solid ${T.border}`, maxWidth: '70%',
        display: 'inline-flex', alignItems: 'center', gap: 6,
      }}>
        <Icons.bolt size={11} stroke={T.textDim}/> {m.text} · <span style={{ color: T.textFaint }}>{m.time}</span>
      </div>
    );
  }
  const fromPatient = m.from === 'patient';
  return (
    <div style={{
      display: 'flex', flexDirection: 'column',
      alignItems: fromPatient ? 'flex-start' : 'flex-end',
      gap: 4,
    }}>
      <div style={{
        maxWidth: '74%',
        padding: '10px 13px',
        borderRadius: fromPatient ? '14px 14px 14px 4px' : '14px 14px 4px 14px',
        background: fromPatient ? T.surfaceAlt : T.accent,
        color: fromPatient ? T.text : '#fff',
        fontSize: 13.5, lineHeight: 1.5,
        border: fromPatient ? `1px solid ${T.border}` : 'none',
      }}>
        {m.text}
      </div>
      <div style={{ fontSize: 10.5, color: T.textFaint, padding: '0 4px', fontFamily: T.mono }}>
        {fromPatient ? m.time : `${m.author || 'You'} · ${m.time}`}
      </div>
    </div>
  );
}

function ClinicalAISuggestion() {
  const T = ClinicalTokens;
  return (
    <div style={{
      margin: '0 18px 0', padding: '10px 12px',
      background: T.accentSoft, border: `1px solid ${T.accentSoft}`,
      borderRadius: 10, display: 'flex', alignItems: 'flex-start', gap: 10,
    }}>
      <div style={{
        width: 22, height: 22, borderRadius: '50%', background: T.accent,
        color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>
        <Icons.sparkles size={12} strokeWidth={2}/>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: T.accent, marginBottom: 3, letterSpacing: '0.02em', textTransform: 'uppercase' }}>
          Lumen suggests
        </div>
        <div style={{ fontSize: 13, color: T.text, lineHeight: 1.5, marginBottom: 6 }}>
          Dr. Lin has 5:30 PM Thu open. Reply: <em>"Sure — I just moved you to Thu May 28 at 5:30 PM with Dr. Lin. New Zoom link will arrive 30 min before."</em>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button style={{
            fontSize: 11.5, padding: '4px 10px', borderRadius: 5,
            background: T.accent, color: '#fff', border: 'none', cursor: 'pointer',
            fontFamily: 'inherit', fontWeight: 600,
          }}>Use suggestion</button>
          <button style={{
            fontSize: 11.5, padding: '4px 10px', borderRadius: 5,
            background: '#fff', color: T.text, border: `1px solid ${T.border}`,
            cursor: 'pointer', fontFamily: 'inherit', fontWeight: 500,
          }}>Edit</button>
          <button style={{
            fontSize: 11.5, padding: '4px 10px', borderRadius: 5,
            background: 'transparent', color: T.textDim, border: 'none', cursor: 'pointer',
            fontFamily: 'inherit',
          }}>Dismiss</button>
        </div>
      </div>
    </div>
  );
}

function ClinicalPatientPanel() {
  const T = ClinicalTokens;
  return (
    <aside style={{
      width: 300, background: T.surfaceAlt, borderLeft: `1px solid ${T.border}`,
      display: 'flex', flexDirection: 'column', flexShrink: 0, overflow: 'auto',
    }}>
      <div style={{ padding: '18px 18px 14px', textAlign: 'center', borderBottom: `1px solid ${T.border}` }}>
        <Avatar name="Maya Okafor" size={56} palette="A"/>
        <div style={{ fontSize: 15, fontWeight: 600, color: T.text, marginTop: 8, letterSpacing: '-0.01em' }}>Maya Okafor</div>
        <div style={{ fontSize: 12, color: T.textDim, marginTop: 2 }}>F · 34 · Patient since 2017</div>
        <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginTop: 10 }}>
          {[{l:'Visits',v:14},{l:'No-shows',v:0},{l:'NPS',v:9}].map((s, i) => (
            <div key={i} style={{
              flex: 1, padding: '8px 6px', background: T.surface, borderRadius: 7,
              border: `1px solid ${T.border}`,
            }}>
              <div style={{ fontSize: 16, fontWeight: 600, color: T.text, fontFamily: T.mono }}>{s.v}</div>
              <div style={{ fontSize: 10, color: T.textDim, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>

      <PanelSection title="Next appointment" T={T}>
        <div style={{
          background: T.surface, border: `1px solid ${T.border}`, borderRadius: 8,
          padding: 12,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: T.text }}>Video follow-up</div>
            <div style={{ fontSize: 10, color: T.accent, fontWeight: 600 }}>● Thu</div>
          </div>
          <div style={{ fontSize: 11.5, color: T.textDim, marginTop: 3 }}>May 28 · 3:00 PM · 15 min · Dr. Lin</div>
          <div style={{ fontSize: 11, color: T.warn, marginTop: 6, padding: 6, background: '#FBF6EC', borderRadius: 5 }}>
            ⚠ Patient asked to move this in current thread
          </div>
        </div>
      </PanelSection>

      <PanelSection title="Recent visits" T={T}>
        {[
          { date: 'May 14', type: '6-mo checkup', who: 'Dr. Lin' },
          { date: 'Nov 22 \'24', type: 'Annual physical', who: 'Dr. Lin' },
          { date: 'Aug 03 \'24', type: 'Vaccination', who: 'Nurse Ortega' },
        ].map((v, i) => (
          <div key={i} style={{
            display: 'flex', justifyContent: 'space-between',
            padding: '8px 0', borderBottom: i < 2 ? `1px solid ${T.border}` : 'none',
            fontSize: 12,
          }}>
            <div>
              <div style={{ color: T.text, fontWeight: 500 }}>{v.type}</div>
              <div style={{ color: T.textDim, fontSize: 11 }}>{v.who}</div>
            </div>
            <div style={{ color: T.textDim, fontFamily: T.mono, fontSize: 11 }}>{v.date}</div>
          </div>
        ))}
      </PanelSection>

      <PanelSection title="Tags" T={T}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
          {['Annual labs', 'Preventive', 'Email opt-in', 'SMS preferred', 'PPO BlueShield'].map((t, i) => (
            <span key={i} style={{
              fontSize: 11, padding: '3px 8px', borderRadius: 4,
              background: T.surface, border: `1px solid ${T.border}`, color: T.textDim,
            }}>{t}</span>
          ))}
          <button style={{ ...chip(T), padding: '3px 8px', fontSize: 11 }}>+ Add</button>
        </div>
      </PanelSection>

      <PanelSection title="Notes" T={T}>
        <div style={{
          fontSize: 12, color: T.textDim, lineHeight: 1.55,
          padding: 10, background: T.surface, border: `1px solid ${T.border}`, borderRadius: 7,
        }}>
          Prefers SMS for routine communication. Worked overnight shifts Apr–May, schedule accordingly. Husband is also a patient (Tomás O.).
        </div>
      </PanelSection>
    </aside>
  );
}

function PanelSection({ title, children, T }) {
  return (
    <div style={{ padding: '14px 16px', borderBottom: `1px solid ${T.border}` }}>
      <div style={{
        fontSize: 10.5, color: T.textDim, fontWeight: 600,
        textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8,
      }}>{title}</div>
      {children}
    </div>
  );
}

function iconBtn(T) {
  return {
    width: 26, height: 26, borderRadius: 6, border: `1px solid ${T.border}`,
    background: T.surface, color: T.textDim, display: 'inline-flex',
    alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
    fontFamily: 'inherit',
  };
}
function chip(T) {
  return {
    display: 'inline-flex', alignItems: 'center', gap: 5,
    fontSize: 11.5, padding: '4px 8px', borderRadius: 5,
    background: T.surface, color: T.textDim, border: `1px solid ${T.border}`,
    fontFamily: 'inherit', cursor: 'pointer', fontWeight: 500,
  };
}

function InboxClinical() {
  const T = ClinicalTokens;
  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex',
      background: T.bg, fontFamily: T.font, color: T.text,
      fontSize: 13, fontFeatureSettings: '"cv11", "ss01"',
    }}>
      <ClinicalSidebar/>
      <ClinicalThreadList/>
      <ClinicalConversationPane/>
      <ClinicalPatientPanel/>
    </div>
  );
}

window.InboxClinical = InboxClinical;
window.ClinicalTokens = ClinicalTokens;
