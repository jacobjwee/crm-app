// Settings.jsx — Clinic configuration · channels, hours, templates, team

function Settings() {
  const T = ClinicalTokens;
  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex',
      background: T.bg, fontFamily: T.font, color: T.text, fontSize: 13,
    }}>
      <ClinicalSidebar2 active=""/>

      {/* settings sub-nav */}
      <aside style={{
        width: 220, background: T.surface, borderRight: `1px solid ${T.border}`,
        display: 'flex', flexDirection: 'column', flexShrink: 0,
      }}>
        <div style={{ padding: '20px 18px 12px' }}>
          <div style={{ fontSize: 11, color: T.textDim, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Settings</div>
          <div style={{ fontSize: 15, fontWeight: 600, marginTop: 4 }}>Maple Family Clinic</div>
        </div>
        <nav style={{ padding: '0 8px 12px' }}>
          {[
            { group: 'Clinic', items: [
              { l: 'General', active: false },
              { l: 'Hours & holidays' },
              { l: 'Locations', sub: '2' },
              { l: 'Branding' },
            ]},
            { group: 'Messaging', items: [
              { l: 'Channels', active: true },
              { l: 'Templates', sub: '24' },
              { l: 'AI assistant' },
              { l: 'Quiet hours' },
              { l: 'Auto-replies' },
            ]},
            { group: 'Workflow', items: [
              { l: 'Team & roles', sub: '6' },
              { l: 'Routing rules' },
              { l: 'Tags' },
              { l: 'Custom fields' },
            ]},
            { group: 'Integrations', items: [
              { l: 'EHR · Athena' },
              { l: 'Billing · Stripe' },
              { l: 'Calendar sync' },
              { l: 'API & webhooks' },
            ]},
            { group: 'Account', items: [
              { l: 'Plan & billing' },
              { l: 'Audit log' },
              { l: 'Compliance · HIPAA' },
            ]},
          ].map((g, gi) => (
            <div key={gi} style={{ marginTop: gi ? 14 : 0 }}>
              <div style={{ fontSize: 10, color: T.textFaint, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', padding: '4px 10px' }}>{g.group}</div>
              {g.items.map((it, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', padding: '6px 10px',
                  fontSize: 12.5, color: it.active ? T.text : T.textDim,
                  fontWeight: it.active ? 600 : 400, borderRadius: 6,
                  background: it.active ? T.accentSoft : 'transparent',
                  borderLeft: it.active ? `2px solid ${T.accent}` : '2px solid transparent',
                  marginLeft: it.active ? -2 : 0, cursor: 'pointer',
                }}>
                  <span style={{ flex: 1 }}>{it.l}</span>
                  {it.sub ? <span style={{ fontSize: 10.5, color: T.textFaint, fontFamily: T.mono }}>{it.sub}</span> : null}
                </div>
              ))}
            </div>
          ))}
        </nav>
      </aside>

      {/* main content */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        <div style={{
          padding: '20px 32px 16px', borderBottom: `1px solid ${T.border}`, background: T.surface,
        }}>
          <div style={{ fontSize: 11.5, color: T.textDim, fontFamily: T.mono, marginBottom: 4 }}>SETTINGS · MESSAGING</div>
          <h1 style={{ margin: 0, fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em' }}>Channels</h1>
          <div style={{ fontSize: 12, color: T.textDim, marginTop: 4 }}>How patients can reach you, and how you reach back.</div>
        </div>

        <div style={{ padding: 32, display: 'flex', flexDirection: 'column', gap: 18, maxWidth: 960 }}>
          {/* SMS */}
          <ChannelCard T={T}
            name="SMS"
            channel="sms"
            status="connected"
            num="+1 (415) 555-0100"
            sub="Twilio · A2P 10DLC registered · 200 msg/day soft cap"
            stats={[['Messages this month', '1,284'], ['Reply rate', '74%'], ['Avg time-to-first-reply', '4m 12s']]}
          >
            <SettingRow T={T} label="Display name" value="Maple Family Clinic" />
            <SettingRow T={T} label="Default sender" value="Dr. Lin's care team" />
            <SettingRow T={T} label="MMS attachments" value="Enabled · max 5MB" />
            <SettingRow T={T} label="Two-way conversations" value="On" toggle />
            <SettingRow T={T} label="Patient must confirm opt-in" value="On (HIPAA)" toggle />
            <SettingRow T={T} label="Auto-link short URLs" value="lumen.link/m" />
          </ChannelCard>

          {/* WhatsApp */}
          <ChannelCard T={T}
            name="WhatsApp"
            channel="whatsapp"
            status="connected"
            num="+1 (415) 555-0100"
            sub="WhatsApp Business · 18 approved templates"
            stats={[['Messages this month', '386'], ['Reply rate', '81%'], ['Spanish-preferred patients', '32%']]}
          />

          {/* Email */}
          <ChannelCard T={T}
            name="Email"
            channel="email"
            status="connected"
            num="care@maplefamilyclinic.com"
            sub="Postmark · DKIM/SPF verified · 99.4% deliverability"
            stats={[['Sent this month', '512'], ['Open rate', '64%'], ['Click rate', '22%']]}
          />

          {/* Voice */}
          <ChannelCard T={T}
            name="Voice & voicemail-to-SMS"
            channel="voice"
            status="warning"
            num="+1 (415) 555-0100"
            sub="Voicemails transcribed → SMS thread · 1 prompt missing"
            stats={[['Voicemails (7d)', '23'], ['Auto-transcribed', '100%'], ['Avg duration', '0:47']]}
          />

          {/* In-app */}
          <ChannelCard T={T}
            name="In-app chat (patient portal)"
            channel="chat"
            status="off"
            num="lumen.app/p/maple"
            sub="Embed widget · 0 active sessions"
            stats={[['Status', 'Not connected'], ['Setup time', '~5 min'], ['Plan', 'Included']]}
          />
        </div>
      </div>
    </div>
  );
}

function ChannelCard({ T, name, channel, status, num, sub, stats = [], children }) {
  const statusDot = {
    connected: { c: T.success, l: 'Connected' },
    warning: { c: T.warn, l: 'Action needed' },
    off: { c: T.textFaint, l: 'Off' },
  }[status];
  return (
    <div style={{
      background: T.surface, border: `1px solid ${T.border}`, borderRadius: 12,
    }}>
      <div style={{
        padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 14,
        borderBottom: children ? `1px solid ${T.border}` : 'none',
      }}>
        <div style={{
          width: 40, height: 40, borderRadius: 9, display: 'flex',
          alignItems: 'center', justifyContent: 'center',
          background: T.accentSoft, color: T.accent,
        }}>
          <ChannelDot channel={channel} size={16}/>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 2 }}>
            <span style={{ fontSize: 15, fontWeight: 600, color: T.text }}>{name}</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11, color: statusDot.c, fontWeight: 600 }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: statusDot.c }}/> {statusDot.l}
            </span>
          </div>
          <div style={{ fontSize: 12, color: T.textDim, fontFamily: T.mono }}>{num}</div>
          <div style={{ fontSize: 11.5, color: T.textFaint, marginTop: 2 }}>{sub}</div>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          {stats.map(([l, v], i) => (
            <div key={i} style={{ textAlign: 'right', minWidth: 100 }}>
              <div style={{ fontSize: 10, color: T.textDim, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{l}</div>
              <div style={{ fontSize: 14, fontWeight: 600, fontFamily: T.mono, color: T.text, marginTop: 2 }}>{v}</div>
            </div>
          ))}
          <button style={{
            padding: '7px 14px', borderRadius: 7, background: T.surface, color: T.text,
            border: `1px solid ${T.border}`, fontFamily: 'inherit', fontSize: 12, fontWeight: 500, cursor: 'pointer',
            alignSelf: 'center',
          }}>{status === 'off' ? 'Connect' : 'Manage'}</button>
        </div>
      </div>
      {children ? <div style={{ padding: '8px 20px 14px' }}>{children}</div> : null}
    </div>
  );
}

function SettingRow({ T, label, value, toggle }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', padding: '10px 0',
      borderBottom: `1px solid ${T.border}`,
    }}>
      <span style={{ flex: 1, fontSize: 12.5, color: T.text, fontWeight: 500 }}>{label}</span>
      <span style={{ fontSize: 12, color: T.textDim, marginRight: 12 }}>{value}</span>
      {toggle ? (
        <div style={{
          width: 32, height: 18, background: T.accent, borderRadius: 9, position: 'relative',
        }}>
          <div style={{
            position: 'absolute', top: 2, right: 2, width: 14, height: 14, background: '#fff', borderRadius: '50%',
            boxShadow: '0 1px 2px rgba(0,0,0,0.15)',
          }}/>
        </div>
      ) : (
        <button style={{
          fontSize: 11, color: T.accent, background: 'transparent', border: 'none', cursor: 'pointer',
          fontFamily: 'inherit', fontWeight: 600,
        }}>Edit</button>
      )}
    </div>
  );
}

window.Settings = Settings;
